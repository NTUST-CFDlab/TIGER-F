! 03 May 2026 - FDS



 ! Definition of staggered grid terms for the QUICK scheme formula
 !------------------------------------------------------------------
 !
 ! Postive parallel velocity (face value):    
 !__________________________________:___________________________________________
 !          |               |       :       |
 !          |       :       |       :       |
 !     -->  |  -->  o  -->  |  -->  o  -->  |  -->     -->     -->
 !          |       :       |       :       |
 !         u(i-1)           u(i)    ue      u(i+1)
 !          |<----iDx(i)--->|<---iDx(i+1)-->|
 !                  |<----Dxs(i)--->|
 !------------------------------------------------------------------------------
 !                          
 ! Negative parallel velocity (face value): 
 !__________________________________:___________________________________________
 !                          |       :       |               |
 !                          |       :       |       :       |
 !     <--     <--     <--  |  <--  o  <--  |  <--  o  <--  |  <--
 !                          |       :       |       :       |
 !                          u(i)    ue      u(i+1)          u(i+2)
 !                          |<---iDx(i+1)-->|<---iDx(i+2)-->|
 !                                  |<---Dxs(i+1)-->|
 !------------------------------------------------------------------------------


 !------------------------------------------------------------------------------
 ! 
 ! Postive transverse velocity (cell center value): 
 !__________________________________|___________________________________________
 !                  |               |        
 !          :       |       :       |       :
 !     -->  o  -->  |  -->  o  -->  |  -->  o  -->     -->     -->
 !          :       |       :       |       :
 !         v(i-1)           v(i)    ve      v(i+1)
 !          |<---Dxs(i-1)-->|<----Dxs(i)--->|
 !                  |<----iDx(i)--->|
 !------------------------------------------------------------------------------
 !
 ! Negative transverse velocity (cell center value):
 !__________________________________|___________________________________________
 !                                  |               |        
 !                          :       |       :       |       :
 !     <--     <--     <--  o  <--  |  <--  o  <--  |  <--  o  <--
 !                          :       |       :       |       :
 !                          v(i)    ve      v(i+1)          v(i+2)
 !                          |<----Dxs(i)--->|<--Dxs(i+1)--->|
 !                                  |<--iDx(i+1)--->|
 !----------------------------------|-------------------------------------------


subroutine discretisation_QUICK_centre()
  use variables
  implicit none
    real(fp)	:: lw,qw,ETA_face

!!! u_star calculation (x component) !!!
!$acc data present(iDx,iDy,iDz,Dxs,Dys,Dzs,ETA,nut(:,:,istart-2:iend+2),theta(:,:,istart-2:iend+2), &
!$acc	     u(:,:,istart-2:iend+2),     v(:,:,istart-2:iend+2),     w(:,:,istart-2:iend+2), &
!$acc	u_star(:,:,istart-2:iend+2),v_star(:,:,istart-2:iend+2),w_star(:,:,istart-2:iend+2))

  !$OMP PARALLEL
   !$OMP DO               PRIVATE(lw,qw,u_tilde_x1,u_tilde_x2,v_tilde_x1,v_tilde_x2,w_tilde_x1,w_tilde_x2, &
   !$OMP						  ue,uw,un,us,uf,ub,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
   !$acc parallel
   !$acc loop independent private(lw,qw,u_tilde_x1,u_tilde_x2,v_tilde_x1,v_tilde_x2,w_tilde_x1,w_tilde_x2, &
   !$acc						  ue,uw,un,us,uf,ub,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
   do k=istart,iend
   do j=1,ny; do i=1,nx

      u_tilde_x1 = 0.5d0 * (u(i+1,j,k)+u(i,j,k)) 
      u_tilde_x2 = 0.5d0 * (u(i-1,j,k)+u(i,j,k))
      v_tilde_x1 = 0.5d0 * (v(i,j,k)+v(i+1,j,k))
      v_tilde_x2 = 0.5d0 * (v(i,j-1,k)+v(i+1,j-1,k))
      w_tilde_x1 = 0.5d0 * (w(i+1,j,k)+w(i,j,k))
      w_tilde_x2 = 0.5d0 * (w(i,j,k-1)+w(i+1,j,k-1))

        if (u_tilde_x1 > 0) then 
			ue = 0.5d0*(u(i,j,k)     + u(i+1,j,k)  ) -0.125d0*iDx(i+1)*iDx(i+1)/Dxs(i)* &
					(  (u(i+1,j,k)   - u(i,j,k)    ) / iDx(i+1) &
					 - (u(i,j,k)     - u(i-1,j,k)  ) / iDx(i)   )
        else
			ue = 0.5d0*(u(i,j,k)     + u(i+1,j,k)  ) -0.125d0*iDx(i+1)*iDx(i+1)/Dxs(i+1)* &
					(  (u(i+2,j,k)   - u(i+1,j,k)  ) / iDx(i+2) &
					 - (u(i+1,j,k)   - u(i,j,k)    ) / iDx(i+1) )
        end if

        if (u_tilde_x2 > 0) then 
			uw = 0.5d0*(u(i-1,j,k)   + u(i,j,k)    ) -0.125d0*iDx(i)*iDx(i)/Dxs(i-1)* &
					(  (u(i,j,k)     - u(i-1,j,k)  ) / iDx(i)   &
					 - (u(i-1,j,k)   - u(i-2,j,k)  ) / iDx(i-1) ) 
        else
			uw = 0.5d0*(u(i-1,j,k)   + u(i,j,k)    ) -0.125d0*iDx(i)*iDx(i)/Dxs(i)* &
					(  (u(i+1,j,k)   - u(i,j,k)    ) / iDx(i+1) &
					 - (u(i,j,k)     - u(i-1,j,k)  ) / iDx(i)   ) 
        end if


        if (v_tilde_x1 > 0) then 
			lw = 0.5d0*iDy(j)/Dys(j)
			qw = 0.5d0*iDy(j)*(Dys(j)-0.5d0*iDy(j))/(Dys(j-1)+Dys(j))

			un = (1.d0-lw)*u(i,j,k)   + lw*u(i,j+1,k) -  			&
					qw*( (u(i,j+1,k)  - u(i,j,k)    ) / Dys(j) 		&
						-(u(i,j,k)    - u(i,j-1,k)  ) / Dys(j-1) ) 
        else
			lw = 0.5d0*iDy(j+1)/Dys(j)
			qw = 0.5d0*iDy(j+1)*(Dys(j)-0.5d0*iDy(j+1))/(Dys(j)+Dys(j+1))
			
			un = (1.d0-lw)*u(i,j+1,k) + lw*u(i,j,k)   -				&
					qw*( (u(i,j+2,k)  - u(i,j+1,k))   / Dys(j+1) 	&
					- (u(i,j+1,k)     - u(i,j,k)  )   / Dys(j)   )
        end if

        if (v_tilde_x2 > 0) then 
			lw = 0.5d0*iDy(j-1)/Dys(j-1)
			qw = 0.5d0*iDy(j-1)*(Dys(j-1)-0.5d0*iDy(j-1))/(Dys(j-2)+Dys(j-1))
			
			us = (1.d0-lw)*u(i,j-1,k) + lw*u(i,j,k)   -				&
					qw*( (u(i,j,k)    - u(i,j-1,k)  ) / Dys(j-1)   	&
					- (u(i,j-1,k)     - u(i,j-2,k)  ) / Dys(j-2) )  
        else
			lw = 0.5d0*iDy(j)/Dys(j-1)
			qw = 0.5d0*iDy(j)*(Dys(j-1)-0.5d0*iDy(j))/(Dys(j-1)+Dys(j))
			
			us = (1.d0-lw)*u(i,j,k)   + lw*u(i,j-1,k)   -			&
					qw*( (u(i,j+1,k)  - u(i,j,k)    ) / Dys(j) 		&
					- (u(i,j,k)       - u(i,j-1,k)  ) / Dys(j-1) )  
        end if


        if (w_tilde_x1 > 0) then 
			lw = 0.5d0*iDz(k)/Dzs(k)
			qw = 0.5d0*iDz(k)*(Dzs(k)-0.5d0*iDz(k))/(Dzs(k-1)+Dzs(k))
			
			uf = (1.d0-lw)*u(i,j,k)   + lw*u(i,j,k+1) -  			&
					qw*( (u(i,j,k+1)  - u(i,j,k)    ) / Dzs(k) 		&
				    -(u(i,j,k) 		  - u(i,j,k-1)  ) / Dzs(k-1) )
        else
			lw = 0.5d0*iDz(k+1)/Dzs(k)
			qw = 0.5d0*iDz(k+1)*(Dzs(k)-0.5d0*iDz(k+1))/(Dzs(k)+Dzs(k+1))
			
			uf = (1.d0-lw)*u(i,j,k+1) + lw*u(i,j,k)   -				&
					qw*( (u(i,j,k+2)  - u(i,j,k+1))   / Dzs(k+1) 	&
					- (u(i,j,k+1)     - u(i,j,k)  )   / Dzs(k)   )
        end if

        if (w_tilde_x2 > 0) then 
			lw = 0.5d0*iDz(k-1)/Dzs(k-1)
			qw = 0.5d0*iDz(k-1)*(Dzs(k-1)-0.5d0*iDz(k-1))/(Dzs(k-2)+Dzs(k-1))
			
			ub = (1.d0-lw)*u(i,j,k-1) + lw*u(i,j,k)   -				&
					qw*( (u(i,j,k)    - u(i,j,k-1)  ) / Dzs(k-1)   &
					- (u(i,j,k-1)     - u(i,j,k-2)  ) / Dzs(k-2) )   
        else
			lw = 0.5d0*iDz(k)/Dzs(k-1)
			qw = 0.5d0*iDz(k)*(Dzs(k-1)-0.5d0*iDz(k))/(Dzs(k-1)+Dzs(k))
			
			ub = (1.d0-lw)*u(i,j,k)   + lw*u(i,j,k-1)   -			&
					qw*( (u(i,j,k+1)  - u(i,j,k)    ) / Dzs(k) 		&
					- (u(i,j,k)       - u(i,j,k-1)  ) / Dzs(k-1) ) 
        end if
		
		Viseff_e = nu + LES*nut(i+1,j,k)	! at east face
		Viseff_w = nu + LES*nut(i,j,k)		! at west face
		Viseff_n = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j+1,k)+nut(i+1,j+1,k))	! at north face, simplified with uniform grid assumption
		Viseff_s = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j-1,k)+nut(i+1,j-1,k))	! at south face, simplified with uniform grid assumption
		Viseff_f = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j,k+1)+nut(i+1,j,k+1))	! at front face, simplified with uniform grid assumption
		Viseff_b = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j,k-1)+nut(i+1,j,k-1))	! at back face, simplified with uniform grid assumption
		
		! ETA_face = ETA(i,j,k)*0.5d0*iDx(i+1)/Dxs(i) + ETA(i+1,j,k)*0.5d0*iDx(i)/Dxs(i)	! for buoyancy term

        u_star(i,j,k) = - (u_tilde_x1*ue-u_tilde_x2*uw) / Dxs(i) 	&
						- (v_tilde_x1*un-v_tilde_x2*us) / iDy(j) 	&
						- (w_tilde_x1*uf-w_tilde_x2*ub) / iDz(k) 	&

                        + (Viseff_e*(u(i+1,j,k)-u(i,j,k)) / iDx(i+1) - Viseff_w*(u(i,j,k)-u(i-1,j,k)) / iDx(i)   ) / Dxs(i) &
                        + (Viseff_n*(u(i,j+1,k)-u(i,j,k)) / Dys(j)   - Viseff_s*(u(i,j,k)-u(i,j-1,k)) / Dys(j-1) ) / iDy(j) &
                        + (Viseff_f*(u(i,j,k+1)-u(i,j,k)) / Dzs(k)   - Viseff_b*(u(i,j,k)-u(i,j,k-1)) / Dzs(k-1) ) / iDz(k)
						!+ buoy_accel*(0.5d0*(theta(i,j,k)+theta(i+1,j,k))-T_inf)*(1.d0-ETA_face)
                        

  	end do;end do
  	end do
  	!$OMP END DO


!!! v_star calculation (y component) !!!

   !$OMP DO               PRIVATE(lw,qw,u_tilde_y1,u_tilde_y2,v_tilde_y1,v_tilde_y2,w_tilde_y1,w_tilde_y2, &
   !$OMP						  ve,vw,vn,vs,vf,vb,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
   !$acc loop independent private(lw,qw,u_tilde_y1,u_tilde_y2,v_tilde_y1,v_tilde_y2,w_tilde_y1,w_tilde_y2, &
   !$acc						  ve,vw,vn,vs,vf,vb,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
   do k=istart,iend
   do j=1,ny;do i=1,nx

      u_tilde_y1 = 0.5d0 * (u(i,j,k)+u(i,j+1,k))
      u_tilde_y2 = 0.5d0 * (u(i-1,j,k)+u(i-1,j+1,k))
      v_tilde_y1 = 0.5d0 * (v(i,j,k)+v(i,j+1,k))
      v_tilde_y2 = 0.5d0 * (v(i,j-1,k)+v(i,j,k))
      w_tilde_y1 = 0.5d0 * (w(i,j,k)+w(i,j+1,k))
      w_tilde_y2 = 0.5d0 * (w(i,j,k-1)+w(i,j+1,k-1))

        if (u_tilde_y1 > 0) then 
			lw = 0.5d0*iDx(i)/Dxs(i)
			qw = 0.5d0*iDx(i)*(Dxs(i)-0.5d0*iDx(i))/(Dxs(i-1)+Dxs(i))
			
			ve = (1.d0-lw)*v(i,j,k)   + lw*v(i+1,j,k) -  			&
					qw*( (v(i+1,j,k)  - v(i,j,k)    ) / Dxs(i) 		&
					-(v(i,j,k)        - v(i-1,j,k)  ) / Dxs(i-1) )
        else
			lw = 0.5d0*iDx(i+1)/Dxs(i)
			qw = 0.5d0*iDx(i+1)*(Dxs(i)-0.5d0*iDx(i+1))/(Dxs(i)+Dxs(i+1))
			
			ve = (1.d0-lw)*v(i+1,j,k) + lw*v(i,j,k)   -				&
					qw*( (v(i+2,j,k)  - v(i+1,j,k))   / Dxs(i+1) 	&
					- (v(i+1,j,k)     - v(i,j,k)  )   / Dxs(i)   ) 
        end if

        if (u_tilde_y2 > 0) then 
			lw = 0.5d0*iDx(i-1)/Dxs(i-1)
			qw = 0.5d0*iDx(i-1)*(Dxs(i-1)-0.5d0*iDx(i-1))/(Dxs(i-2)+Dxs(i-1))
			
			vw = (1.d0-lw)*v(i-1,j,k) + lw*v(i,j,k)   -				&
					qw*( (v(i,j,k)    - v(i-1,j,k)  ) / Dxs(i-1)   	&
					- (v(i-1,j,k)     - v(i-2,j,k)  ) / Dxs(i-2) ) 
        else 
			lw = 0.5d0*iDx(i)/Dxs(i-1)
			qw = 0.5d0*iDx(i)*(Dxs(i-1)-0.5d0*iDx(i))/(Dxs(i-1)+Dxs(i))
			
			vw = (1.d0-lw)*v(i,j,k)   + lw*v(i-1,j,k)   -			&
					qw*( (v(i+1,j,k)  - v(i,j,k)    ) / Dxs(i) 		&
					- (v(i,j,k)       - v(i-1,j,k)  ) / Dxs(i-1) )  
        end if


        if (v_tilde_y1 > 0) then 
			vn = 0.5d0*(v(i,j,k)     + v(i,j+1,k)  ) -0.125d0*iDy(j+1)*iDy(j+1)/Dys(j)* &
					(  (v(i,j+1,k)   - v(i,j,k)    ) / iDy(j+1) &
					 - (v(i,j,k)     - v(i,j-1,k)  ) / iDy(j)   ) 
        else
			vn = 0.5d0*(v(i,j,k)     + v(i,j+1,k)  ) -0.125d0*iDy(j+1)*iDy(j+1)/Dys(j+1)* &
					(  (v(i,j+2,k)   - v(i,j+1,k)  ) / iDy(j+2) &
					 - (v(i,j+1,k)   - v(i,j,k)    ) / iDy(j+1) ) 
        end if

        if (v_tilde_y2 > 0) then 
			vs = 0.5d0*(v(i,j-1,k)   + v(i,j,k)    ) -0.125d0*iDy(j)*iDy(j)/Dys(j-1)* &
					(  (v(i,j,k)     - v(i,j-1,k)  ) / iDy(j)   &
					 - (v(i,j-1,k)   - v(i,j-2,k)  ) / iDy(j-1) ) 
        else
			vs = 0.5d0*(v(i,j-1,k)   + v(i,j,k)    ) -0.125d0*iDy(j)*iDy(j)/Dys(j)* &
					(  (v(i,j+1,k)   - v(i,j,k)    ) / iDy(j+1)&
					 - (v(i,j,k)     - v(i,j-1,k)  ) / iDy(j)  ) 
        end if


        if (w_tilde_y1 > 0) then 
			lw = 0.5d0*iDz(k)/Dzs(k)
			qw = 0.5d0*iDz(k)*(Dzs(k)-0.5d0*iDz(k))/(Dzs(k-1)+Dzs(k))
			
			vf = (1.d0-lw)*v(i,j,k)   + lw*v(i,j,k+1) -  			&
					qw*( (v(i,j,k+1)  - v(i,j,k)    ) / Dzs(k) 		&
						-(v(i,j,k)    - v(i,j,k-1)  ) / Dzs(k-1) )
        else
			lw = 0.5d0*iDz(k+1)/Dzs(k)
			qw = 0.5d0*iDz(k+1)*(Dzs(k)-0.5d0*iDz(k+1))/(Dzs(k)+Dzs(k+1))
			
			vf = (1.d0-lw)*v(i,j,k+1) + lw*v(i,j,k)   -				&
					qw*( (v(i,j,k+2)  - v(i,j,k+1))   / Dzs(k+1) 	&
					- (v(i,j,k+1)     - v(i,j,k)  )   / Dzs(k)   )
        end if

        if (w_tilde_y2 > 0) then 
			lw = 0.5d0*iDz(k-1)/Dzs(k-1)
			qw = 0.5d0*iDz(k-1)*(Dzs(k-1)-0.5d0*iDz(k-1))/(Dzs(k-2)+Dzs(k-1))
			
			vb = (1.d0-lw)*v(i,j,k-1) + lw*v(i,j,k)   -				&
					qw*( (v(i,j,k)    - v(i,j,k-1)  ) / Dzs(k-1)   	&
					- (v(i,j,k-1)     - v(i,j,k-2)  ) / Dzs(k-2) ) 
        else
			lw = 0.5d0*iDz(k)/Dzs(k-1)
			qw = 0.5d0*iDz(k)*(Dzs(k-1)-0.5d0*iDz(k))/(Dzs(k-1)+Dzs(k))
			
			vb = (1.d0-lw)*v(i,j,k)   + lw*v(i,j,k-1)   -			&
					qw*( (v(i,j,k+1)  - v(i,j,k)    ) / Dzs(k) 		&
					- (v(i,j,k)       - v(i,j,k-1)  ) / Dzs(k-1) ) 
        end if


		Viseff_e = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i+1,j,k)+nut(i+1,j+1,k))	! at east face, simplified with uniform grid assumption
		Viseff_w = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i-1,j,k)+nut(i-1,j+1,k))	! at west face, simplified with uniform grid assumption
		Viseff_n = nu + LES*nut(i,j+1,k)	! at north face
		Viseff_s = nu + LES*nut(i,j,k)		! at south face
		Viseff_f = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i,j,k+1)+nut(i,j+1,k+1))	! at front face, simplified with uniform grid assumption
		Viseff_b = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i,j,k-1)+nut(i,j+1,k-1))	! at back face, simplified with uniform grid assumption
		
		! ETA_face = ETA(i,j,k)*0.5d0*iDy(j+1)/Dys(j) + ETA(i,j+1,k)*0.5d0*iDy(j)/Dys(j)		! for buoyancy term

        v_star(i,j,k) = - (u_tilde_y1*ve-u_tilde_y2*vw) / iDx(i)	&
                        - (v_tilde_y1*vn-v_tilde_y2*vs) / Dys(j)	&
                        - (w_tilde_y1*vf-w_tilde_y2*vb) / iDz(k)	&

                        + (Viseff_e*(v(i+1,j,k)-v(i,j,k)) / Dxs(i)   - Viseff_w*(v(i,j,k) - v(i-1,j,k)) / Dxs(i-1) ) / iDx(i) &
                        + (Viseff_n*(v(i,j+1,k)-v(i,j,k)) / iDy(j+1) - Viseff_s*(v(i,j,k) - v(i,j-1,k)) / iDy(j) )   / Dys(j) &
                        + (Viseff_f*(v(i,j,k+1)-v(i,j,k)) / Dzs(k)   - Viseff_b*(v(i,j,k) - v(i,j,k-1)) / Dzs(k-1) ) / iDz(k)
                        !+ buoy_accel*(0.5d0*(theta(i,j,k)+theta(i,j+1,k))-T_inf)*(1.d0-ETA_face)
						!+ 0.5d0*( F_tavey(i,j,k)+F_tavey(i,j+1,k) *unDBD_onoff
                        !- ( Viseff*ABS(F_tavey(i,j,k)) )
    
  end do;end do
  end do
  !$OMP END DO  
  

!!! w_star calculation (z component) !!!

   !$OMP DO               PRIVATE(lw,qw,u_tilde_z1,u_tilde_z2,v_tilde_z1,v_tilde_z2,w_tilde_z1,w_tilde_z2, &
   !$OMP						  we,ww,wn,ws,wf,wb,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
   !$acc loop independent private(lw,qw,u_tilde_z1,u_tilde_z2,v_tilde_z1,v_tilde_z2,w_tilde_z1,w_tilde_z2, &
   !$acc						  we,ww,wn,ws,wf,wb,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
   do k=istart,iend 
   do j=1,ny;do i=1,nx

        u_tilde_z1 = 0.5d0 * (u(i,j,k+1)+u(i,j,k)) 
        u_tilde_z2 = 0.5d0 * (u(i-1,j,k+1)+u(i-1,j,k))  
        v_tilde_z1 = 0.5d0 * (v(i,j,k)+v(i,j,k+1))
        v_tilde_z2 = 0.5d0 * (v(i,j-1,k+1)+v(i,j-1,k))
        w_tilde_z1 = 0.5d0 * (w(i,j,k+1)+w(i,j,k))
        w_tilde_z2 = 0.5d0 * (w(i,j,k)+w(i,j,k-1))

        if (u_tilde_z1 > 0) then 
			lw = 0.5d0*iDx(i)/Dxs(i)
			qw = 0.5d0*iDx(i)*(Dxs(i)-0.5d0*iDx(i))/(Dxs(i-1)+Dxs(i))
			
			we = (1.d0-lw)*w(i,j,k)   + lw*w(i+1,j,k) -  			&
					qw*( (w(i+1,j,k)  - w(i,j,k)    ) / Dxs(i) 		&
				    -(w(i,j,k)        - w(i-1,j,k)  ) / Dxs(i-1) )
        else
			lw = 0.5d0*iDx(i+1)/Dxs(i)
			qw = 0.5d0*iDx(i+1)*(Dxs(i)-0.5d0*iDx(i+1))/(Dxs(i)+Dxs(i+1))
			
			we = (1.d0-lw)*w(i+1,j,k) + lw*w(i,j,k)   -				&
					qw*( (w(i+2,j,k)  - w(i+1,j,k))   / Dxs(i+1) 	&
					- (w(i+1,j,k)     - w(i,j,k)  )   / Dxs(i)   )
        end if

        if (u_tilde_z2 > 0) then 
			lw = 0.5d0*iDx(i-1)/Dxs(i-1)
			qw = 0.5d0*iDx(i-1)*(Dxs(i-1)-0.5d0*iDx(i-1))/(Dxs(i-2)+Dxs(i-1))
			
			ww = (1.d0-lw)*w(i-1,j,k) + lw*w(i,j,k)   -				&
					qw*( (w(i,j,k)    - w(i-1,j,k)  ) / Dxs(i-1)   	&
					- (w(i-1,j,k)     - w(i-2,j,k)  ) / Dxs(i-2) ) 
        else 
			lw = 0.5d0*iDx(i)/Dxs(i-1)
			qw = 0.5d0*iDx(i)*(Dxs(i-1)-0.5d0*iDx(i))/(Dxs(i-1)+Dxs(i))
			
			ww = (1.d0-lw)*w(i,j,k)   + lw*w(i-1,j,k)   -			&
					qw*( (w(i+1,j,k)  - w(i,j,k)    ) / Dxs(i) 		&
					- (w(i,j,k)       - w(i-1,j,k)  ) / Dxs(i-1) ) 
        end if


        if (v_tilde_z1 > 0) then 
			lw = 0.5d0*iDy(j)/Dys(j)
			qw = 0.5d0*iDy(j)*(Dys(j)-0.5d0*iDy(j))/(Dys(j-1)+Dys(j))
			
			wn = (1.d0-lw)*w(i,j,k)   + lw*w(i,j+1,k) -  			&
					qw*( (w(i,j+1,k)  - w(i,j,k)    ) / Dys(j) 		&
				    -(w(i,j,k)        - w(i,j-1,k)  ) / Dys(j-1) )
        else
			lw = 0.5d0*iDy(j+1)/Dys(j)
			qw = 0.5d0*iDy(j+1)*(Dys(j)-0.5d0*iDy(j+1))/(Dys(j)+Dys(j+1))
			
			wn = (1.d0-lw)*w(i,j+1,k) + lw*w(i,j,k)   -				&
					qw*( (w(i,j+2,k)  - w(i,j+1,k))   / Dys(j+1) 	&
					- (w(i,j+1,k)     - w(i,j,k)  )   / Dys(j)   )
        end if

        if (v_tilde_z2 > 0) then 
			lw = 0.5d0*iDy(j-1)/Dys(j-1)
			qw = 0.5d0*iDy(j-1)*(Dys(j-1)-0.5d0*iDy(j-1))/(Dys(j-2)+Dys(j-1))
			
			ws = (1.d0-lw)*w(i,j-1,k) + lw*w(i,j,k)   -				&
					qw*( (w(i,j,k)    - w(i,j-1,k)  ) / Dys(j-1)   	&
					- (w(i,j-1,k)     - w(i,j-2,k)  ) / Dys(j-2) ) 
        else
			lw = 0.5d0*iDy(j)/Dys(j-1)
			qw = 0.5d0*iDy(j)*(Dys(j-1)-0.5d0*iDy(j))/(Dys(j-1)+Dys(j))
			
			ws = (1.d0-lw)*w(i,j,k)   + lw*w(i,j-1,k)   -			&
					qw*( (w(i,j+1,k)  - w(i,j,k)    ) / Dys(j) 		&
					- (w(i,j,k)       - w(i,j-1,k)  ) / Dys(j-1) ) 
        end if


        if (w_tilde_z1 > 0) then 
			wf = 0.5d0*(w(i,j,k)     + w(i,j,k+1)  ) -0.125d0*iDz(k+1)*iDz(k+1)/Dzs(k)* &
					(  (w(i,j,k+1)   - w(i,j,k)    ) / iDz(k+1)&
					 - (w(i,j,k)     - w(i,j,k-1)  ) / iDz(k)  )
        else
		wf = 0.5d0*(w(i,j,k)     + w(i,j,k+1)  ) -0.125d0*iDz(k+1)*iDz(k+1)/Dzs(k+1)* &
					(  (w(i,j,k+2)   - w(i,j,k+1)  ) / iDz(k+2)&
					 - (w(i,j,k+1)   - w(i,j,k)    ) / iDz(k+1))
        end if

        if (w_tilde_z2 > 0) then 
		wb = 0.5d0*(w(i,j,k-1)   + w(i,j,k)    ) -0.125d0*iDz(k)*iDz(k)/Dzs(k-1)* &
					(  (w(i,j,k)     - w(i,j,k-1)  ) / iDz(k)  &
					 - (w(i,j,k-1)   - w(i,j,k-2)  ) / iDz(k-1))
        else
		wb = 0.5d0*(w(i,j,k-1)   + w(i,j,k)    ) -0.125d0*iDz(k)*iDz(k)/Dzs(k)* &
					(  (w(i,j,k+1)   - w(i,j,k)    ) / iDz(k+1)&
					 - (w(i,j,k)     - w(i,j,k-1)  ) / iDz(k)  )
        end if

		Viseff_e = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i+1,j,k)+nut(i+1,j,k+1))	! at east face, simplified with uniform grid assumption
		Viseff_w = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i-1,j,k)+nut(i-1,j,k+1))	! at west face, simplified with uniform grid assumption
		Viseff_n = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i,j+1,k)+nut(i,j+1,k+1))	! at north face, simplified with uniform grid assumption
		Viseff_s = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i,j-1,k)+nut(i,j-1,k+1))	! at south face, simplified with uniform grid assumption
		Viseff_f = nu + LES*nut(i,j,k+1)	! at front face
		Viseff_b = nu + LES*nut(i,j,k)		! at back face

		! ETA_face = ETA(i,j,k)*0.5d0*iDz(k+1)/Dzs(k) + ETA(i,j,k+1)*0.5d0*iDz(k)/Dzs(k)		! for buoyancy term

        w_star(i,j,k) = - (u_tilde_z1*we-u_tilde_z2*ww) / iDx(i)	&
                        - (v_tilde_z1*wn-v_tilde_z2*ws) / iDy(j)	&
                        - (w_tilde_z1*wf-w_tilde_z2*wb) / Dzs(k)	&
                                
                        + (Viseff_e*( w(i+1,j,k)-w(i,j,k) ) / Dxs(i)   - Viseff_w*( w(i,j,k)-w(i-1,j,k) ) / Dxs(i-1)  ) / iDx(i) &
                        + (Viseff_n*( w(i,j+1,k)-w(i,j,k) ) / Dys(j)   - Viseff_s*( w(i,j,k)-w(i,j-1,k) ) / Dys(j-1)  ) / iDy(j) &
                        + (Viseff_f*( w(i,j,k+1)-w(i,j,k) ) / iDz(k+1) - Viseff_b*( w(i,j,k)-w(i,j,k-1) ) / iDz(k)    ) / Dzs(k)
                        !+ buoy_accel*(0.5d0*(theta(i,j,k)+theta(i,j,k+1))-T_inf)*(1.d0-ETA_face)
                        !+ 0.5d0*( F_tavex(i,j,k)+F_tavex(i,j,k+1) *unDBD_onoff
                        !+ ( Viseff*ABS(F_tavex(i,j,k)) )
  end do;end do
  end do
  !$acc end parallel
  !$OMP END DO
 !$OMP END PARALLEL
!$acc end data

end subroutine discretisation_QUICK_centre
