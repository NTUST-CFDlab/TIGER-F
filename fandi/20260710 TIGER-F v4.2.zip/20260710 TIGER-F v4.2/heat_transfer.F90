! 09 July 2026 - FDS


 !------------------------------------------------------------------------------
 ! 
 ! Postive transverse velocity (cell center value): 
 !__________________________________|___________________________________________
 !                  |               |        
 !          :       |       :       |       :
 !     -->  o  -->  |  -->  o  -->  |  -->  o  -->     -->     -->
 !          :       |       :       |       :
 !       theta(i-1)       theta(i)  tte   theta(i+1)
 !          |<---Dxs(i-1)-->|<----Dxs(i)--->|
 !                  |<----iDx(i)--->|
 !------------------------------------------------------------------------------
 !
 ! Negative transverse velocity (cell center value):
 !__________________________________|___________________________________________
 !                                  |               |        
 !                          :       |       :       |       :
 !     <--     <--     <--  o  <--  |  <--  o  <--  |  <--  o  <--
 !                          :       |       :       |       :
 !                        theta(i)  tte   theta(i+1)      theta(i+2)
 !                          |<----Dxs(i)--->|<--Dxs(i+1)--->|
 !                                  |<--iDx(i+1)--->|
 !----------------------------------|-------------------------------------------


subroutine discretisation_QUICK_HT()
  use variables
  implicit none
    real(fp)	:: u_tilde,v_tilde,w_tilde
    real(fp)	:: tte,ttw,ttn,tts,ttf,ttb


!$acc data present(iDx,iDy,iDz,Dxs,Dys,Dzs,nut(:,:,istart:iend+1), 					&
!$acc		lw_u_tilde_1_p,lw_u_tilde_1_n,lw_u_tilde_2_p,lw_u_tilde_2_n, 			&
!$acc		lw_v_tilde_1_p,lw_v_tilde_1_n,lw_v_tilde_2_p,lw_v_tilde_2_n, 			&
!$acc		lw_w_tilde_1_p,lw_w_tilde_1_n,lw_w_tilde_2_p,lw_w_tilde_2_n, 			&
!$acc		qw_u_tilde_1_p,qw_u_tilde_1_n,qw_u_tilde_2_p,qw_u_tilde_2_n, 			&
!$acc		qw_v_tilde_1_p,qw_v_tilde_1_n,qw_v_tilde_2_p,qw_v_tilde_2_n, 			&
!$acc		qw_w_tilde_1_p,qw_w_tilde_1_n,qw_w_tilde_2_p,qw_w_tilde_2_n, 			&
!$acc	    u(:,:,istart-2:iend+2), v(:,:,istart-2:iend+2), w(:,:,istart-2:iend+2),	&
!$acc	theta(:,:,istart-2:iend+2),thetastar(:,:,istart-2:iend+2))


   !$OMP PARALLEL DO PRIVATE(u_tilde,v_tilde,w_tilde,tte,ttw,ttn,tts,ttf,ttb,alpha,	&
   !$OMP   			  		 tcc,te1,tw1,te2,tw2,tn1,ts1,tn2,ts2,tf1,tb1,tf2,tb2) COLLAPSE(3)
   !$acc parallel
   !$acc loop 		 private(u_tilde,v_tilde,w_tilde,tte,ttw,ttn,tts,ttf,ttb,alpha,	&
   !$acc  			  		 tcc,te1,tw1,te2,tw2,tn1,ts1,tn2,ts2,tf1,tb1,tf2,tb2) collapse(3) gang vector
   do k=istart,iend
   do j=1,ny; do i=1,nx

     tcc  = theta(i,j,k)
     te1  = theta(i+1,j,k)
     tw1  = theta(i-1,j,k)
     te2  = theta(i+2,j,k)
     tw2  = theta(i-2,j,k)
     tn1  = theta(i,j+1,k)
     ts1  = theta(i,j-1,k)
     tn2  = theta(i,j+2,k)
     ts2  = theta(i,j-2,k)
     tf1  = theta(i,j,k+1)
     tb1  = theta(i,j,k-1)
     tf2  = theta(i,j,k+2)
     tb2  = theta(i,j,k-2)

		u_tilde = 0.5d0 * (u(i,j,k)+u(i-1,j,k))
		v_tilde = 0.5d0 * (v(i,j,k)+v(i,j-1,k))
		w_tilde = 0.5d0 * (w(i,j,k)+w(i,j,k-1))
		
        if (u_tilde > 0) then 
			tte = (1.d0-lw_u_tilde_1_p(i))*tcc   + lw_u_tilde_1_p(i)*te1 -  &
				  qw_u_tilde_1_p(i)*( (te1     - tcc    ) / Dxs(i) 			&
								    - (tcc       - tw1  ) / Dxs(i-1) )
			
			ttw = (1.d0-lw_u_tilde_2_p(i))*tw1 + lw_u_tilde_2_p(i)*tcc   -	&
				  qw_u_tilde_2_p(i)*( (tcc       - tw1  ) / Dxs(i-1)   		&
									- (tw1     - tw2  ) / Dxs(i-2) )  
        else
			tte = (1.d0-lw_u_tilde_1_n(i))*te1 + lw_u_tilde_1_n(i)*tcc   -	&
				  qw_u_tilde_1_n(i)*( (te2     - te1)   / Dxs(i+1) 		&
									- (te1     - tcc  )   / Dxs(i)   )
			
			ttw = (1.d0-lw_u_tilde_2_n(i))*tcc   + lw_u_tilde_2_n(i)*tw1 -	&
				  qw_u_tilde_2_n(i)*( (te1     - tcc    ) / Dxs(i) 			&
									- (tcc       - tw1  ) / Dxs(i-1) ) 
        end if


        if (v_tilde > 0) then 
			ttn = (1.d0-lw_v_tilde_1_p(j))*tcc   + lw_v_tilde_1_p(j)*tn1 -  &
				  qw_v_tilde_1_p(j)*( (tn1     - tcc    ) / Dys(j) 			&
									- (tcc       - ts1  ) / Dys(j-1) )

			tts = (1.d0-lw_v_tilde_2_p(j))*ts1 + lw_v_tilde_2_p(j)*tcc   -	&
				  qw_v_tilde_2_p(j)*( (tcc       - ts1  ) / Dys(j-1)   		&
									- (ts1     - ts2  ) / Dys(j-2) )   
        else
			ttn = (1.d0-lw_v_tilde_1_n(j))*tn1 + lw_v_tilde_1_n(j)*tcc   -	&
				  qw_v_tilde_1_n(j)*( (tn2     - tn1)   / Dys(j+1) 		&
									- (tn1     - tcc  )   / Dys(j)   )
			
			tts = (1.d0-lw_v_tilde_2_n(j))*tcc   + lw_v_tilde_2_n(j)*ts1 -	&
				  qw_v_tilde_2_n(j)*( (tn1     - tcc    ) / Dys(j) 			&
									- (tcc       - ts1  ) / Dys(j-1) ) 
        end if


       if (w_tilde > 0) then 
			ttf = (1.d0-lw_w_tilde_1_p(k))*tcc   + lw_w_tilde_1_p(k)*tf1 -  &
				  qw_w_tilde_1_p(k)*( (tf1     - tcc    ) / Dzs(k) 	&
									- (tcc       - tb1  ) / Dzs(k-1) )
			
			ttb = (1.d0-lw_w_tilde_2_p(k))*tb1 + lw_w_tilde_2_p(k)*tcc   -	&
				  qw_w_tilde_2_p(k)*( (tcc       - tb1  ) / Dzs(k-1)   		&
									- (tb1     - tb2  ) / Dzs(k-2) )  
        else
			ttf = (1.d0-lw_w_tilde_1_n(k))*tf1 + lw_w_tilde_1_n(k)*tcc   -	&
				  qw_w_tilde_1_n(k)*( (tf2     - tf1)   / Dzs(k+1) 		&
									- (tf1     - tcc  )   / Dzs(k)   )
			
			ttb = (1.d0-lw_w_tilde_2_n(k))*tcc   + lw_w_tilde_2_n(k)*tb1 -	&
				  qw_w_tilde_2_n(k)*( (tf1     - tcc    ) / Dzs(k) 			&
									- (tcc       - tb1  ) / Dzs(k-1) ) 
        end if


		alpha = (1.d0-ETA(i,j,k)) * (alpha_f_ + nut(i,j,k)/Prt) + ETA(i,j,k)*alpha_s

        thetastar(i,j,k) = - u_tilde * (tte - ttw) / iDx(i) 	&
						   - v_tilde * (ttn - tts) / iDy(j) 	&
						   - w_tilde * (ttf - ttb) / iDz(k) 	&

                       + alpha*( (te1-tcc) / Dxs(i) - (tcc-tw1) / Dxs(i-1) ) / iDx(i) &
                       + alpha*( (tn1-tcc) / Dys(j) - (tcc-ts1) / Dys(j-1) ) / iDy(j) &
                       + alpha*( (tf1-tcc) / Dzs(k) - (tcc-tb1) / Dzs(k-1) ) / iDz(k)
                        
  	end do;end do;end do
	!$acc end parallel   
    !$OMP END PARALLEL DO

!$acc end data

end subroutine discretisation_QUICK_HT



subroutine AdamsBashforth_HT()
    use variables
    implicit none
    real(fp)	:: r_dt1, r_dt2, c2_a, c2_b


!$acc data present(theta(:,:,istart-2:iend+2),theta0(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2), &
!$acc			   thetastar(:,:,istart-2:iend+2),thetastar1(:,:,istart-2:iend+2))

	r_dt1 = dt_1/dt			!2nd order

    if( istep >= 2) then

		c2_a  = 1.d0 + 0.5d0/r_dt1		!2nd order
		c2_b  = -0.5d0/r_dt1			!2nd order

		!$OMP PARALLEL DO COLLAPSE(3) 
		!$acc parallel loop independent collapse(3) gang vector 
		do k=istart,iend 
		do j=1,ny; do i=1,nx
		
            theta0(i,j,k) = theta(i,j,k) + ( c2_a * thetastar(i,j,k) + c2_b * thetastar1(i,j,k) ) * dt
			theta1(i,j,k) = theta0(i,j,k)

			thetastar1(i,j,k) = thetastar(i,j,k)		!2nd order

		enddo; enddo; enddo
		!$acc end parallel
		!$OMP END PARALLEL DO


    else if( istep == 1) then

		!$OMP PARALLEL DO COLLAPSE(3) 
		!$acc parallel loop independent collapse(3) gang vector 
		do k=istart,iend 
		do j=1,ny; do i=1,nx

            theta0(i,j,k) = theta(i,j,k) + thetastar(i,j,k) * dt
			theta1(i,j,k) = theta0(i,j,k)

			thetastar1(i,j,k) = thetastar(i,j,k)		!2nd order

		enddo; enddo; enddo
		!$acc end parallel
		!$OMP END PARALLEL DO

    end if


!$acc end data	

	dt_1  = dt			!2nd order
	
end subroutine AdamsBashforth_HT



subroutine calcul_heat_src()
   use variables
   implicit none
   
! Sending data to accelerator
!$acc data present(Xs,Ys,Zs,ETA,theta0(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2),Ftheta(:,:,istart-2:iend+2))

  !$OMP PARALLEL DO   COLLAPSE(3)
  !$acc parallel loop collapse(3) gang vector
   do k=istart,iend 
   do j=1,ny;do i=1,nx

	  ! Heat source active zone
	  if( SQRT((Zs(k)-z0_t)**2 + (Ys(j)-y0_t)**2) .LT. (0.1d0)) then
		theta1(i,j,k) = theta0(i,j,k) + ETA(i,j,k) * heat_src * dt
	  endif

      Ftheta(i,j,k) = (theta1(i,j,k) - theta0(i,j,k)) * inv_dt
	  
   end do; end do; end do
   !$acc end parallel 
   !$OMP END PARALLEL DO

!$acc end data

end subroutine calcul_heat_src



subroutine calcul_new_theta()
   use variables
   implicit none
   
! Sending data to accelerator
!$acc data present(ETA,theta0(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2),Ftheta(:,:,istart-2:iend+2))

  !$OMP PARALLEL DO   PRIVATE(Tsolid1) COLLAPSE(3)
  !$acc parallel loop private(Tsolid1) collapse(3) gang vector
   do k=istart,iend 
   do j=1,ny;do i=1,nx
      
	  Tsolid1 = Tsolid

      theta1(i,j,k) = ETA(i,j,k) * Tsolid1 + (1.d0- ETA(i,j,k)) * theta0(i,j,k)
      
      Ftheta(i,j,k) = (theta1(i,j,k) - theta0(i,j,k)) * inv_dt
	  
   end do; end do; end do
   !$acc end parallel 
   !$OMP END PARALLEL DO

!$acc end data

end subroutine calcul_new_theta



subroutine Updating_theta()
   use variables
   implicit none

!$acc data present(theta(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2),dtheta_dt(:,:,istart-2:iend+2))


   !$OMP PARALLEL DO COLLAPSE(3) 
   !$acc parallel loop collapse(3) gang vector
   do k=istart,iend  
   do j=1,ny;do i=1,nx

	  dtheta_dt(i,j,k) = (theta1(i,j,k) - theta(i,j,k))  * inv_dt

      theta(i,j,k) = theta1(i,j,k)    		

   end do; end do; end do
   !$acc end parallel
   !$OMP END PARALLEL DO


!$acc end data   
   
end subroutine Updating_theta



subroutine thermalForceIntegrator()
	use variables
	implicit none

	totalFtheta = 0.d0

!$acc data present(iDx,iDy,iDz,Ftheta(:,:,istart-2:iend+2))

   !$OMP PARALLEL DO 			   REDUCTION(+: totalFtheta) COLLAPSE(3)
   !$acc parallel loop independent reduction(+: totalFtheta) collapse(3) gang vector
	do k=istart,iend 
	do j=1,ny;do i=1,nx
	
	  if(ETA(i,j,k) .GT. 0.d0) then
		totalFtheta = totalFtheta + ( Ftheta(i,j,k) * iDx(i)*iDy(j)*iDz(k) )
	  endif
	end do;end do;end do
   !$acc end parallel 
   !$OMP END PARALLEL DO
!$acc end data 

    call MPI_ALLREDUCE( totalFtheta, totalFtheta_, 1, MPI_REAL8, MPI_SUM, MPI_COMM_WORLD, ierr )

	Qsolid = - den_flu*cp_f*totalFtheta_		! Solid Cooling/Heating rate
	
	Nu_global = - totalFtheta_/alpha_f_/deltaT_max	! Nusselt*A/L

end subroutine thermalForceIntegrator