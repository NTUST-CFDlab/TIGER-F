! 09 July 2026 - FDS



 ! Definition of staggered grid terms for the QUICK scheme formula
 !------------------------------------------------------------------
 !
 ! Postive parallel velocity (face value):    
 !__________________________________:___________________________________________
 !          |               |       :       |
 !          |       :       |       :       |
 !     -->  |  -->  o  -->  |  -->  o  -->  |  -->     -->     -->
 !          |       :       |       :       |
 !         u(i-1)           u(i)    ue      u(i+1)
 !          |<----iDx(i)--->|<---iDx(i+1)-->|
 !                  |<----Dxs(i)--->|
 !------------------------------------------------------------------------------
 !                          
 ! Negative parallel velocity (face value): 
 !__________________________________:___________________________________________
 !                          |       :       |               |
 !                          |       :       |       :       |
 !     <--     <--     <--  |  <--  o  <--  |  <--  o  <--  |  <--
 !                          |       :       |       :       |
 !                          u(i)    ue      u(i+1)          u(i+2)
 !                          |<---iDx(i+1)-->|<---iDx(i+2)-->|
 !                                  |<---Dxs(i+1)-->|
 !------------------------------------------------------------------------------


 !------------------------------------------------------------------------------
 ! 
 ! Postive transverse velocity (cell center value): 
 !__________________________________|___________________________________________
 !                  |               |        
 !          :       |       :       |       :
 !     -->  o  -->  |  -->  o  -->  |  -->  o  -->     -->     -->
 !          :       |       :       |       :
 !         v(i-1)           v(i)    ve      v(i+1)
 !          |<---Dxs(i-1)-->|<----Dxs(i)--->|
 !                  |<----iDx(i)--->|
 !------------------------------------------------------------------------------
 !
 ! Negative transverse velocity (cell center value):
 !__________________________________|___________________________________________
 !                                  |               |        
 !                          :       |       :       |       :
 !     <--     <--     <--  o  <--  |  <--  o  <--  |  <--  o  <--
 !                          :       |       :       |       :
 !                          v(i)    ve      v(i+1)          v(i+2)
 !                          |<----Dxs(i)--->|<--Dxs(i+1)--->|
 !                                  |<--iDx(i+1)--->|
 !----------------------------------|-------------------------------------------



subroutine discretisation_QUICK_centre()
  use variables
  implicit none

!********************************** Convection - QUICK **********************************************

!$acc data present(iDx,iDy,iDz,Dxs,Dys,Dzs,ETA,nut(:,:,istart-2:iend+2),theta(:,:,istart-2:iend+2), &
!$acc		lw_u_tilde_1_p,lw_u_tilde_1_n,lw_u_tilde_2_p,lw_u_tilde_2_n, 							&
!$acc		lw_v_tilde_1_p,lw_v_tilde_1_n,lw_v_tilde_2_p,lw_v_tilde_2_n, 							&
!$acc		lw_w_tilde_1_p,lw_w_tilde_1_n,lw_w_tilde_2_p,lw_w_tilde_2_n, 							&
!$acc		qw_u_tilde_1_p,qw_u_tilde_1_n,qw_u_tilde_2_p,qw_u_tilde_2_n, 							&
!$acc		qw_v_tilde_1_p,qw_v_tilde_1_n,qw_v_tilde_2_p,qw_v_tilde_2_n, 							&
!$acc		qw_w_tilde_1_p,qw_w_tilde_1_n,qw_w_tilde_2_p,qw_w_tilde_2_n, 							&
!$acc	    u(:,:,istart-2:iend+2),		v(:,:,istart-2:iend+2),		w(:,:,istart-2:iend+2), 		&
!$acc  u_star(:,:,istart-2:iend+2),v_star(:,:,istart-2:iend+2),w_star(:,:,istart-2:iend+2))


  !!! u_star calculation (x component) !!!
  !$OMP PARALLEL
	!$OMP DO PRIVATE  (u_tilde_x1,u_tilde_x2,v_tilde_x1,v_tilde_x2,w_tilde_x1,w_tilde_x2, 	&
	!$OMP  			  ucc,ue1,uw1,ue2,uw2,un1,us1,un2,us2,uf1,ub1,uf2,ub2, 					&
	!$OMP			  ue,uw,un,us,uf,ub) COLLAPSE(3)
  !$acc parallel
	!$acc loop private(u_tilde_x1,u_tilde_x2,v_tilde_x1,v_tilde_x2,w_tilde_x1,w_tilde_x2, 	&
	!$acc  			  ucc,ue1,uw1,ue2,uw2,un1,us1,un2,us2,uf1,ub1,uf2,ub2, 					&
	!$acc			  ue,uw,un,us,uf,ub) collapse(3) gang vector
	do k=istart,iend
	do j=1,ny; do i=1,nx

     ucc  = u(i,j,k)
     ue1  = u(i+1,j,k)
     uw1  = u(i-1,j,k)
     ue2  = u(i+2,j,k)
     uw2  = u(i-2,j,k)
     un1  = u(i,j+1,k)
     us1  = u(i,j-1,k)
     un2  = u(i,j+2,k)
     us2  = u(i,j-2,k)
     uf1  = u(i,j,k+1)
     ub1  = u(i,j,k-1)
     uf2  = u(i,j,k+2)
     ub2  = u(i,j,k-2)

      u_tilde_x1 = 0.5d0 * (ue1+ucc) 
      u_tilde_x2 = 0.5d0 * (uw1+ucc)
	  v_tilde_x1 = 0.5d0 * (v(i,j,k) + v(i+1,j,k))
	  v_tilde_x2 = 0.5d0 * (v(i,j-1,k) + v(i+1,j-1,k))
	  w_tilde_x1 = 0.5d0 * (w(i+1,j,k) + w(i,j,k))
	  w_tilde_x2 = 0.5d0 * (w(i,j,k-1) + w(i+1,j,k-1))

        if (u_tilde_x1 > 0) then 
			ue = 0.5d0*(ucc + ue1) -0.125d0*iDx(i+1)*iDx(i+1)/Dxs(i)* 		&
					(  (ue1 - ucc) / iDx(i+1) &
					 - (ucc - uw1) / iDx(i)   )
        else
			ue = 0.5d0*(ucc + ue1) -0.125d0*iDx(i+1)*iDx(i+1)/Dxs(i+1)* 	&
					(  (ue2 - ue1) / iDx(i+2) &
					 - (ue1 - ucc) / iDx(i+1) )
        end if

        if (u_tilde_x2 > 0) then 
			uw = 0.5d0*(uw1 + ucc) -0.125d0*iDx(i)*iDx(i)/Dxs(i-1)* 		&
					(  (ucc - uw1) / iDx(i)   &
					 - (uw1 - uw2) / iDx(i-1) ) 
        else
			uw = 0.5d0*(uw1 + ucc) -0.125d0*iDx(i)*iDx(i)/Dxs(i)* 			&
					(  (ue1 - ucc) / iDx(i+1) &
					 - (ucc - uw1) / iDx(i)   ) 
        end if


        if (v_tilde_x1 > 0) then 

			un = (1.d0-lw_v_tilde_1_p(j))*ucc + lw_v_tilde_1_p(j)*un1 -		&
					   qw_v_tilde_1_p(j)*( (un1 - ucc) / Dys(j) 			&
										 - (ucc - us1) / Dys(j-1) ) 
        else
			
			un = (1.d0-lw_v_tilde_1_n(j))*un1 + lw_v_tilde_1_n(j)*ucc -		&
					   qw_v_tilde_1_n(j)*( (un2 - un1) / Dys(j+1) 			&
										 - (un1 - ucc) / Dys(j)   )
        end if

        if (v_tilde_x2 > 0) then 
			
			us = (1.d0-lw_v_tilde_2_p(j))*us1 + lw_v_tilde_2_p(j)*ucc -		&
					   qw_v_tilde_2_p(j)*( (ucc - us1) / Dys(j-1)   		&
										 - (us1 - us2) / Dys(j-2) )  
        else
			
			us = (1.d0-lw_v_tilde_2_n(j))*ucc   + lw_v_tilde_2_n(j)*us1 -	&
					   qw_v_tilde_2_n(j)*( (un1 - ucc) / Dys(j) 			&
										 - (ucc - us1) / Dys(j-1) )  
        end if


        if (w_tilde_x1 > 0) then 
			
			uf = (1.d0-lw_w_tilde_1_p(k))*ucc   + lw_w_tilde_1_p(k)*uf1 -	&
					   qw_w_tilde_1_p(k)*( (uf1 - ucc) / Dzs(k) 			&
										 - (ucc - ub1) / Dzs(k-1) )
        else
			
			uf = (1.d0-lw_w_tilde_1_n(k))*uf1 + lw_w_tilde_1_n(k)*ucc -		&
					   qw_w_tilde_1_n(k)*( (uf2 - uf1) / Dzs(k+1) 			&
										 - (uf1 - ucc) / Dzs(k)   )
        end if

        if (w_tilde_x2 > 0) then 
			
			ub = (1.d0-lw_w_tilde_2_p(k))*ub1 + lw_w_tilde_2_p(k)*ucc -		&
					   qw_w_tilde_2_p(k)*( (ucc - ub1) / Dzs(k-1)   		&
										 - (ub1 - ub2) / Dzs(k-2) )   
        else
			
			ub = (1.d0-lw_w_tilde_2_n(k))*ucc   + lw_w_tilde_2_n(k)*ub1 -	&
					   qw_w_tilde_2_n(k)*( (uf1 - ucc) / Dzs(k) 			&
										 - (ucc - ub1) / Dzs(k-1) ) 
        end if
		

        u_star(i,j,k) = - (u_tilde_x1*ue-u_tilde_x2*uw) / Dxs(i) 	&
						- (v_tilde_x1*un-v_tilde_x2*us) / iDy(j) 	&
						- (w_tilde_x1*uf-w_tilde_x2*ub) / iDz(k)


  	end do;end do
  	end do
  	!$OMP END DO


   !!! v_star calculation (y component) !!!
	!$OMP DO PRIVATE  (u_tilde_y1,u_tilde_y2,v_tilde_y1,v_tilde_y2,w_tilde_y1,w_tilde_y2, 	&
	!$OMP   		  vcc,ve1,vw1,ve2,vw2,vn1,vs1,vn2,vs2,vf1,vb1,vf2,vb2, 					&
	!$OMP 			  ve,vw,vn,vs,vf,vb) COLLAPSE(3)
	!$acc loop private(u_tilde_y1,u_tilde_y2,v_tilde_y1,v_tilde_y2,w_tilde_y1,w_tilde_y2, 	&
	!$acc   		  vcc,ve1,vw1,ve2,vw2,vn1,vs1,vn2,vs2,vf1,vb1,vf2,vb2, 					&
	!$acc			  ve,vw,vn,vs,vf,vb) collapse(3) gang vector
	do k=istart,iend
	do j=1,ny;do i=1,nx

     vcc  = v(i,j,k)
     ve1  = v(i+1,j,k)
     vw1  = v(i-1,j,k)
     ve2  = v(i+2,j,k)
     vw2  = v(i-2,j,k)
     vn1  = v(i,j+1,k)
     vs1  = v(i,j-1,k)
     vn2  = v(i,j+2,k)
     vs2  = v(i,j-2,k)
     vf1  = v(i,j,k+1)
     vb1  = v(i,j,k-1)
     vf2  = v(i,j,k+2)
     vb2  = v(i,j,k-2)

	  u_tilde_y1 = 0.5d0 * (u(i,j,k)+u(i,j+1,k))
	  u_tilde_y2 = 0.5d0 * (u(i-1,j,k)+u(i-1,j+1,k))
      v_tilde_y1 = 0.5d0 * (vcc+vn1)
      v_tilde_y2 = 0.5d0 * (vs1+vcc)
	  w_tilde_y1 = 0.5d0 * (w(i,j,k)+w(i,j+1,k))
	  w_tilde_y2 = 0.5d0 * (w(i,j,k-1)+w(i,j+1,k-1))

        if (u_tilde_y1 > 0) then 
			
			ve = (1.d0-lw_u_tilde_1_p(i))*vcc   + lw_u_tilde_1_p(i)*ve1 -  	&
					   qw_u_tilde_1_p(i)*( (ve1 - vcc) / Dxs(i) 			&
										 - (vcc - vw1) / Dxs(i-1) )
        else
			
			ve = (1.d0-lw_u_tilde_1_n(i))*ve1 + lw_u_tilde_1_n(i)*vcc -		&
					   qw_u_tilde_1_n(i)*( (ve2 - ve1) / Dxs(i+1) 			&
										 - (ve1 - vcc) / Dxs(i)   ) 
        end if

        if (u_tilde_y2 > 0) then 
			
			vw = (1.d0-lw_u_tilde_2_p(i))*vw1 + lw_u_tilde_2_p(i)*vcc -		&
					   qw_u_tilde_2_p(i)*( (vcc - vw1) / Dxs(i-1)   		&
										 - (vw1 - vw2) / Dxs(i-2) ) 
        else 
			
			vw = (1.d0-lw_u_tilde_2_n(i))*vcc   + lw_u_tilde_2_n(i)*vw1 -	&
					   qw_u_tilde_2_n(i)*( (ve1 - vcc) / Dxs(i) 			&
										 - (vcc - vw1) / Dxs(i-1) )  
        end if


        if (v_tilde_y1 > 0) then 
			vn = 0.5d0*(vcc + vn1) -0.125d0*iDy(j+1)*iDy(j+1)/Dys(j)* 		&
					(  (vn1 - vcc) / iDy(j+1) &
					 - (vcc - vs1) / iDy(j)   ) 
        else
			vn = 0.5d0*(vcc + vn1) -0.125d0*iDy(j+1)*iDy(j+1)/Dys(j+1)* 	&
					(  (vn2 - vn1) / iDy(j+2) &
					 - (vn1 - vcc) / iDy(j+1) ) 
        end if

        if (v_tilde_y2 > 0) then 
			vs = 0.5d0*(vs1 + vcc) -0.125d0*iDy(j)*iDy(j)/Dys(j-1)* 		&
					(  (vcc - vs1) / iDy(j)   &
					 - (vs1 - vs2) / iDy(j-1) ) 
        else
			vs = 0.5d0*(vs1 + vcc) -0.125d0*iDy(j)*iDy(j)/Dys(j)* 			&
					(  (vn1 - vcc) / iDy(j+1)&
					 - (vcc - vs1) / iDy(j)  ) 
        end if


        if (w_tilde_y1 > 0) then 
			
			vf = (1.d0-lw_w_tilde_1_p(k))*vcc   + lw_w_tilde_1_p(k)*vf1 -	&
					   qw_w_tilde_1_p(k)*( (vf1 - vcc) / Dzs(k) 			&
										 - (vcc - vb1) / Dzs(k-1) )
        else
			
			vf = (1.d0-lw_w_tilde_1_n(k))*vf1 + lw_w_tilde_1_n(k)*vcc -		&	
					   qw_w_tilde_1_n(k)*( (vf2 - vf1) / Dzs(k+1) 			&
										 - (vf1 - vcc) / Dzs(k)   )
        end if

        if (w_tilde_y2 > 0) then 
			
			vb = (1.d0-lw_w_tilde_2_p(k))*vb1 + lw_w_tilde_2_p(k)*vcc -		&
					   qw_w_tilde_2_p(k)*( (vcc - vb1) / Dzs(k-1)   		&
										 - (vb1 - vb2) / Dzs(k-2) ) 
        else
			
			vb = (1.d0-lw_w_tilde_2_n(k))*vcc   + lw_w_tilde_2_n(k)*vb1 -	&
					   qw_w_tilde_2_n(k)*( (vf1 - vcc) / Dzs(k) 			&
										 - (vcc - vb1) / Dzs(k-1) ) 
        end if

		
        v_star(i,j,k) = - (u_tilde_y1*ve-u_tilde_y2*vw) / iDx(i)	&
                        - (v_tilde_y1*vn-v_tilde_y2*vs) / Dys(j)	&
                        - (w_tilde_y1*vf-w_tilde_y2*vb) / iDz(k)

    
	end do;end do
	end do
	!$OMP END DO  
  

   !!! w_star calculation (z component) !!!
	!$OMP DO PRIVATE  (u_tilde_z1,u_tilde_z2,v_tilde_z1,v_tilde_z2,w_tilde_z1,w_tilde_z2, 	&
	!$OMP 			  wcc,we1,ww1,we2,ww2,wn1,ws1,wn2,ws2,wf1,wb1,wf2,wb2, 					&
	!$OMP 			  we,ww,wn,ws,wf,wb) COLLAPSE(3)
	!$acc loop private(u_tilde_z1,u_tilde_z2,v_tilde_z1,v_tilde_z2,w_tilde_z1,w_tilde_z2, 	&
	!$acc			  wcc,we1,ww1,we2,ww2,wn1,ws1,wn2,ws2,wf1,wb1,wf2,wb2, 					&
	!$acc			  we,ww,wn,ws,wf,wb) collapse(3) gang vector
	do k=istart,iend 
	do j=1,ny;do i=1,nx

     wcc  = w(i,j,k)
     we1  = w(i+1,j,k)
     ww1  = w(i-1,j,k)
     we2  = w(i+2,j,k)
     ww2  = w(i-2,j,k)
     wn1  = w(i,j+1,k)
     ws1  = w(i,j-1,k)
     wn2  = w(i,j+2,k)
     ws2  = w(i,j-2,k)
     wf1  = w(i,j,k+1)
     wb1  = w(i,j,k-1)
     wf2  = w(i,j,k+2)
     wb2  = w(i,j,k-2)

		u_tilde_z1 = 0.5d0 * (u(i,j,k+1)+u(i,j,k)) 
		u_tilde_z2 = 0.5d0 * (u(i-1,j,k+1)+u(i-1,j,k))  
		v_tilde_z1 = 0.5d0 * (v(i,j,k)+v(i,j,k+1))
		v_tilde_z2 = 0.5d0 * (v(i,j-1,k+1)+v(i,j-1,k))
        w_tilde_z1 = 0.5d0 * (wf1+wcc)
        w_tilde_z2 = 0.5d0 * (wcc+wb1)

        if (u_tilde_z1 > 0) then 
			
			we = (1.d0-lw_u_tilde_1_p(i))*wcc   + lw_u_tilde_1_p(i)*we1 -  	&
					   qw_u_tilde_1_p(i)*( (we1 - wcc) / Dxs(i) 			&
										 - (wcc - ww1) / Dxs(i-1) )
        else
			
			we = (1.d0-lw_u_tilde_1_n(i))*we1 + lw_u_tilde_1_n(i)*wcc -		&
					   qw_u_tilde_1_n(i)*( (we2 - we1) / Dxs(i+1) 			&
										 - (we1 - wcc) / Dxs(i)   )
        end if

        if (u_tilde_z2 > 0) then 
			
			ww = (1.d0-lw_u_tilde_2_p(i))*ww1 + lw_u_tilde_2_p(i)*wcc -		&
					   qw_u_tilde_2_p(i)*( (wcc - ww1) / Dxs(i-1)   		&
										 - (ww1 - ww2) / Dxs(i-2) ) 
        else 
			
			ww = (1.d0-lw_u_tilde_2_n(i))*wcc   + lw_u_tilde_2_n(i)*ww1 -	&
					   qw_u_tilde_2_n(i)*( (we1 - wcc) / Dxs(i) 			&
										 - (wcc - ww1) / Dxs(i-1) ) 
        end if


        if (v_tilde_z1 > 0) then 
			
			wn = (1.d0-lw_v_tilde_1_p(j))*wcc   + lw_v_tilde_1_p(j)*wn1 -  	&
					   qw_v_tilde_1_p(j)*( (wn1 - wcc) / Dys(j) 			&
										 - (wcc - ws1) / Dys(j-1) )
        else
			
			wn = (1.d0-lw_v_tilde_1_n(j))*wn1 + lw_v_tilde_1_n(j)*wcc -		&
					   qw_v_tilde_1_n(j)*( (wn2 - wn1) / Dys(j+1) 			&
										 - (wn1 - wcc) / Dys(j)   )
        end if

        if (v_tilde_z2 > 0) then 
			
			ws = (1.d0-lw_v_tilde_2_p(j))*ws1 + lw_v_tilde_2_p(j)*wcc -		&
					   qw_v_tilde_2_p(j)*( (wcc - ws1) / Dys(j-1)   		&
										 - (ws1 - ws2) / Dys(j-2) ) 
        else
			
			ws = (1.d0-lw_v_tilde_2_n(j))*wcc   + lw_v_tilde_2_n(j)*ws1 -	&
					   qw_v_tilde_2_n(j)*( (wn1 - wcc) / Dys(j) 			&
										 - (wcc - ws1) / Dys(j-1) ) 
        end if


        if (w_tilde_z1 > 0) then 
			wf = 0.5d0*(wcc + wf1) -0.125d0*iDz(k+1)*iDz(k+1)/Dzs(k)* 		&
					(  (wf1 - wcc) / iDz(k+1)&
					 - (wcc - wb1) / iDz(k)  )
        else
			wf = 0.5d0*(wcc + wf1) -0.125d0*iDz(k+1)*iDz(k+1)/Dzs(k+1)* 	&
					(  (wf2 - wf1) / iDz(k+2)&
					 - (wf1 - wcc) / iDz(k+1))
        end if

        if (w_tilde_z2 > 0) then 
			wb = 0.5d0*(wb1 + wcc) -0.125d0*iDz(k)*iDz(k)/Dzs(k-1)* 		&
					(  (wcc - wb1) / iDz(k)  &
					 - (wb1 - wb2) / iDz(k-1))
        else
			wb = 0.5d0*(wb1 + wcc) -0.125d0*iDz(k)*iDz(k)/Dzs(k)* 			&
					(  (wf1 - wcc) / iDz(k+1)&
					 - (wcc - wb1) / iDz(k)  )
        end if


        w_star(i,j,k) = - (u_tilde_z1*we-u_tilde_z2*ww) / iDx(i)	&
                        - (v_tilde_z1*wn-v_tilde_z2*ws) / iDy(j)	&
                        - (w_tilde_z1*wf-w_tilde_z2*wb) / Dzs(k)

	end do;end do
	end do
	!$OMP END DO  



!************************* Diffusion - Central difference & source terms ****************************


	!!! u_star calculation (x component) !!!
	!$OMP DO PRIVATE  (ucc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
	!$acc loop private(ucc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
	do k=istart,iend
	do j=1,ny; do i=1,nx

     ucc  = u(i,j,k)
		
		Viseff_e = nu + LES*nut(i+1,j,k)	! at east face
		Viseff_w = nu + LES*nut(i,j,k)		! at west face
		Viseff_n = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j+1,k)+nut(i+1,j+1,k))	! at north face, simplified with uniform grid assumption
		Viseff_s = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j-1,k)+nut(i+1,j-1,k))	! at south face, simplified with uniform grid assumption
		Viseff_f = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j,k+1)+nut(i+1,j,k+1))	! at front face, simplified with uniform grid assumption
		Viseff_b = nu + LES*0.25D0*(nut(i,j,k)+nut(i+1,j,k)+nut(i,j,k-1)+nut(i+1,j,k-1))	! at back face, simplified with uniform grid assumption

        u_star(i,j,k) = u_star(i,j,k) 	&

                        + (Viseff_e*(u(i+1,j,k)-ucc) / iDx(i+1) - Viseff_w*(ucc-u(i-1,j,k)) / iDx(i)   ) / Dxs(i) &
                        + (Viseff_n*(u(i,j+1,k)-ucc) / Dys(j)   - Viseff_s*(ucc-u(i,j-1,k)) / Dys(j-1) ) / iDy(j) &
                        + (Viseff_f*(u(i,j,k+1)-ucc) / Dzs(k)   - Viseff_b*(ucc-u(i,j,k-1)) / Dzs(k-1) ) / iDz(k)

		! buoyancy term for natural convection
		if(heat_transfer/='OFF' .AND. natural_conv=='X') then								
			ETA_face = ETA(i,j,k)*0.5d0*iDx(i+1)/Dxs(i) + ETA(i+1,j,k)*0.5d0*iDx(i)/Dxs(i)
			u_star(i,j,k) = u_star(i,j,k) + buoy_accel*(0.5d0*(theta(i,j,k)+theta(i+1,j,k))-T_inf)*(1.d0-ETA_face)
		endif

  	end do;end do
  	end do
  	!$OMP END DO


	!!! v_star calculation (y component) !!!
	!$OMP DO PRIVATE  (vcc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
	!$acc loop private(vcc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
	do k=istart,iend
	do j=1,ny;do i=1,nx

     vcc  = v(i,j,k)

		Viseff_e = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i+1,j,k)+nut(i+1,j+1,k))	! at east face, simplified with uniform grid assumption
		Viseff_w = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i-1,j,k)+nut(i-1,j+1,k))	! at west face, simplified with uniform grid assumption
		Viseff_n = nu + LES*nut(i,j+1,k)	! at north face
		Viseff_s = nu + LES*nut(i,j,k)		! at south face
		Viseff_f = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i,j,k+1)+nut(i,j+1,k+1))	! at front face, simplified with uniform grid assumption
		Viseff_b = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j+1,k)+nut(i,j,k-1)+nut(i,j+1,k-1))	! at back face, simplified with uniform grid assumption
		

        v_star(i,j,k) = v_star(i,j,k)	&

                        + (Viseff_e*(v(i+1,j,k)-vcc) / Dxs(i)   - Viseff_w*(vcc - v(i-1,j,k)) / Dxs(i-1) ) / iDx(i) &
                        + (Viseff_n*(v(i,j+1,k)-vcc) / iDy(j+1) - Viseff_s*(vcc - v(i,j-1,k)) / iDy(j) )   / Dys(j) &
                        + (Viseff_f*(v(i,j,k+1)-vcc) / Dzs(k)   - Viseff_b*(vcc - v(i,j,k-1)) / Dzs(k-1) ) / iDz(k)
						!+ 0.5d0*( F_tavey(i,j,k)+F_tavey(i,j+1,k) *unDBD_onoff
                        !- ( Viseff*ABS(F_tavey(i,j,k)) )

		! buoyancy term for natural convection
		if(heat_transfer/='OFF' .AND. natural_conv=='Y') then								
			ETA_face = ETA(i,j,k)*0.5d0*iDy(j+1)/Dys(j) + ETA(i,j+1,k)*0.5d0*iDy(j)/Dys(j)
			v_star(i,j,k) = v_star(i,j,k) + buoy_accel*(0.5d0*(theta(i,j,k)+theta(i,j+1,k))-T_inf)*(1.d0-ETA_face)
		endif
    
	end do;end do
	end do
	!$OMP END DO  
  

	!!! w_star calculation (z component) !!!
	!$OMP DO PRIVATE  (wcc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) COLLAPSE(3)
	!$acc loop private(wcc,Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b,ETA_face) collapse(3) gang vector
	do k=istart,iend 
	do j=1,ny;do i=1,nx

     wcc  = w(i,j,k)

		Viseff_e = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i+1,j,k)+nut(i+1,j,k+1))	! at east face, simplified with uniform grid assumption
		Viseff_w = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i-1,j,k)+nut(i-1,j,k+1))	! at west face, simplified with uniform grid assumption
		Viseff_n = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i,j+1,k)+nut(i,j+1,k+1))	! at north face, simplified with uniform grid assumption
		Viseff_s = nu + LES*0.25D0*(nut(i,j,k)+nut(i,j,k+1)+nut(i,j-1,k)+nut(i,j-1,k+1))	! at south face, simplified with uniform grid assumption
		Viseff_f = nu + LES*nut(i,j,k+1)	! at front face
		Viseff_b = nu + LES*nut(i,j,k)		! at back face


        w_star(i,j,k) = w_star(i,j,k)	&
                                
                        + (Viseff_e*( w(i+1,j,k)-wcc ) / Dxs(i)   - Viseff_w*( wcc-w(i-1,j,k) ) / Dxs(i-1)  ) / iDx(i) &
                        + (Viseff_n*( w(i,j+1,k)-wcc ) / Dys(j)   - Viseff_s*( wcc-w(i,j-1,k) ) / Dys(j-1)  ) / iDy(j) &
                        + (Viseff_f*( w(i,j,k+1)-wcc ) / iDz(k+1) - Viseff_b*( wcc-w(i,j,k-1) ) / iDz(k)    ) / Dzs(k)
                        !+ 0.5d0*( F_tavex(i,j,k)+F_tavex(i,j,k+1) *unDBD_onoff
                        !+ ( Viseff*ABS(F_tavex(i,j,k)) )

		! buoyancy term for natural convection
		if(heat_transfer/='OFF' .AND. natural_conv=='Z') then								
			ETA_face = ETA(i,j,k)*0.5d0*iDz(k+1)/Dzs(k) + ETA(i,j,k+1)*0.5d0*iDz(k)/Dzs(k)
			w_star(i,j,k) = w_star(i,j,k) + buoy_accel*(0.5d0*(theta(i,j,k)+theta(i,j,k+1))-T_inf)*(1.d0-ETA_face)
		endif

	end do;end do
	end do
  !$acc end parallel
	!$OMP END DO
  !$OMP END PARALLEL
!$acc end data


end subroutine discretisation_QUICK_centre


