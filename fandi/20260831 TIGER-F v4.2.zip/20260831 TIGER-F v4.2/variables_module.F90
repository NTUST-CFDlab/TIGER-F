! 29 July 2026 - FDS

	
!This module gathers all structures and variable declarations. 
MODULE variables
	!------------------------------------------------------
	use, intrinsic :: iso_fortran_env, only: fp => real64 !
	!------------------------------------------------------
	use mpi
    implicit none 

    real(fp), parameter       	:: PI           = 4.d0*ATAN(1.d0)

    !--------------------- Physical parameters ---------------------!

    real(fp), parameter        	:: U_inf        = 1.d0   	! Free stream velocity = inlet velocity (1.d0 for dimensionless simulation)

    real(fp), parameter       	:: den_flu      = 1.d0  	! Fluid density (1.d0 for dimensionless simulation)
	
	real(fp), parameter        	:: den_sol      = 100.d0  	! Solid density (only needed in 2way)
	
	real(fp), parameter        	:: i_sol        = 500.d0  	! moment of inertia of solid (only needed in 2way)
	
    real(fp), parameter         :: L_ch		 	= 1.d0  	! Characteristic length used in Re calculation (1.d0 for dimensionless simulation)


    real(fp), parameter         :: fixed_Re	 	= 3900.d0	! Reynolds number (for a dimensionless simulation)
	
    real(fp), parameter         :: fixed_nu	 	= 1.d-4		! Kinematic viscosity (for a dimensional simulation)
	
	real(fp), parameter 		:: g			= 9.81d0

    !----------------------- Gridder settings ----------------------!
	
    integer, parameter          :: ny           = 159
			integer, parameter 	:: nyLow 		= 42		!number of grid in lower side for non-uniform-sin4 (from y(0) to nySml)

    integer, parameter          :: nz           = 255
			integer, parameter 	:: nzUps 		= 43		!number of grid in upstream for non-uniform-sin4, sin5 & ground grids (from z(0) to nzSml) 

    integer, parameter          :: nx           = 30    	!Must be an even number if RBSOR is used
			integer, parameter 	:: nxLow 		= 2			!number of grid in lower side for non-uniform-fall

    real(fp), parameter         :: ly           = 24.d0

    real(fp), parameter         :: lz           = 48.d0

    real(fp), parameter         :: lx           = 3.d0

    character(len=30)           :: Gridder      = 'non-uniform-sin4'  	!'uniform', 'non-uniform-sin4' (Kuyper), 'non-uniform-sin4-3D'
                                                                        !'non-uniform-sin5', 'non-uniform-sin5-3D', 'ground-3D', 'read_txt' (format: nx+1 ny+1 nz+1)

    !--------------------- Unequal grid ---------------------!

    real(fp), parameter         :: GridderYc    = 12.d0     ! Center coordinate of fine grid, GridderXc is set at lx/2. Set wrt. the geometry x0 and y0.
    real(fp), parameter         :: GridderZc    = 12.9d0

    real(fp), parameter         :: lySml        = 1.5d0
    integer, parameter          :: nySml        = 75 ! 1423

    real(fp), parameter         :: lzSml        = 3.d0
    integer, parameter          :: nzSml        = 150 ! 1423

    real(fp), parameter         :: lxSml        = 1.05d0    ! for Gridder: non-uniform-sin5-3D, ground-3D
    integer, parameter          :: nxSml        = 105

    real(fp), parameter         :: lyMid        = 2.d0      ! for Gridder: non-uniform, non-uniform-sin, non-uniform-sin2, non-uniform-sin5, non-uniform-sin5-3D, ground-3D
    integer, parameter          :: nyMid        = 4         ! 'Only' nyMid

    real(fp), parameter         :: lzMid        = 2.d0      ! for Gridder: non-uniform, non-uniform-sin, non-uniform-sin2, non-uniform-sin5, non-uniform-sin5-3D, ground-3D
    integer, parameter          :: nzMid        = 4         ! 'Only' nzMid

    real(fp), parameter         :: lxMid        = 2.d0      ! for Gridder: non-uniform-sin5-3D, ground-3D
    integer, parameter          :: nxMid        = 4         ! 'Only' nxMid

    real(fp)                    :: dxSml, dxMid, dx

    real(fp)                    :: dySml, dyMid, dy

    real(fp)                    :: dzSml, dzMid, dz
	

    !--------------------------Momentum B.Cs-----------------------------!

    !    y=1 ______________                                                                                 
    !       /             /|                                                     
    !      /       N     / |                                                          
    !     /____________ /  |                                
    !     |  |         |   |                                                        
    !     |  | B       |   |                                          
    !   W |  | x=y=z=0 | E |                                           
    !     |  |_________|___|x=1                                        
    !     |  /         |  /                                         
    !     | /     S    | /                                        
    !     |/___________|/                                         
    !    z=1 F     
    !   'NEUMANN'     dU/dn = 0
    !   'DIRICHLET'   U = U_inf
    !   'NO_SLIP'     U = 0
    !   'PERIODIC'    Un=U1								***MUST MODIFY SOR.f90 !!!***
	!	'ADVECTIVE'	  U(n+1) = U(n)-dt*Um_avg*dU(n)/dn
    !	*Symmetry bc: 'NEUMANN' for tangential planes + 'NO_SLIP' for normal planes
	!	*Outflow bc (steady flow): 'NEUMANN' for tangential planes + 'ADVECTIVE' for normal planes
	!	*Outflow bc (unsteady flow): All'ADVECTIVE'

    character(len=20)	:: WestWall_u	= 'PERIODIC'
    character(len=20)   :: WestWall_v   = 'PERIODIC'
    character(len=20)   :: WestWall_w   = 'PERIODIC'

    character(len=20)	:: EastWall_u   = 'PERIODIC'
    character(len=20)   :: EastWall_v   = 'PERIODIC'
    character(len=20)   :: EastWall_w   = 'PERIODIC'

    character(len=20)   :: SouthWall_u  = 'NEUMANN'
    character(len=20)   :: SouthWall_v  = 'NO_SLIP'
    character(len=20)   :: SouthWall_w  = 'NEUMANN'
    
    character(len=20)	:: NorthWall_u  = 'NEUMANN'
    character(len=20)   :: NorthWall_v  = 'NO_SLIP'
    character(len=20)   :: NorthWall_w  = 'NEUMANN'

    character(len=20)	:: BackWall_u   = 'NO_SLIP'		! PERIODIC bc for the Back & Front walls
    character(len=20)   :: BackWall_v   = 'NO_SLIP'		! are only supported when running on 
    character(len=20)   :: BackWall_w   = 'DIRICHLET'	! a single MPI process (np=1)

    character(len=20)	:: FrontWall_u  = 'NEUMANN'
    character(len=20)   :: FrontWall_v  = 'NEUMANN'
    character(len=20)   :: FrontWall_w  = 'NEUMANN'
	

    !--------------------------Thermal B.Cs-----------------------------!
    !   'ADIABATIC'   dT/dn = 0   (= Neumann)
    !   'ISOTHERMAL'  T = Tiso    (= Dirichlet)
	!	'HEAT_FLUX'   dT/dn = -q" (Heat flux in dimensional form: (watt/m^2) / k)
    !   'PERIODIC'    Tn=T1

    character(len=20)            :: WestWall	= 'PERIODIC'
			real(fp), parameter	 :: Tiso_W      = 0.d0 		! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_W = 0.d0 		! if HEAT_FLUX is selected

    character(len=20)            :: EastWall    = 'PERIODIC'
			real(fp), parameter	 :: Tiso_E      = 0.d0 		! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_E = 0.d0 		! if HEAT_FLUX is selected

    character(len=20)            :: SouthWall   = 'ADIABATIC'
			real(fp), parameter	 :: Tiso_S      = 0.d0 		! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_S = 0.d0 		! if HEAT_FLUX is selected
    
    character(len=20)            :: NorthWall   = 'ADIABATIC'
			real(fp), parameter	 :: Tiso_N      = 0.d0 		! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_N = 0.d0 		! if HEAT_FLUX is selected

    character(len=20)            :: BackWall    = 'ISOTHERMAL'
			real(fp), parameter	 :: Tiso_B      = 0.d0  	! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_B = 0.d0 		! if HEAT_FLUX is selected

    character(len=20)            :: FrontWall   = 'ADIABATIC'
			real(fp), parameter	 :: Tiso_F      = 0.d0 		! T value if ISOTHERMAL
			real(fp), parameter	 :: heat_flux_F = 0.d0 		! if HEAT_FLUX is selected


    real(fp)				:: T_init  	= 0.d0	! Initial Temperature

    real(fp)				:: T_inf  	= 0.d0	! freestream Temperature

    !---------------------Solid reference position------------------!

    real(fp), parameter         :: x0                  = lx/2.d0    ! Geometry's origin

    real(fp), parameter         :: y0                  = ly/2.d0    ! Geometry's origin

    real(fp), parameter         :: z0                  = 12.d0      ! Geometry's origin

    real(fp), parameter         :: offset_z            = 0.d0  		! offset distance from origin to center of rotation -->    o - - - - - - - - - - - - o
    ! 											                                                                     (z0,y0)<----- offset_z (+)----->center of rotation


	!-----------Tandem Cyl 1-Solid reference position---------------!
	
	
	real(fp), parameter         :: x01                 = lx/2.d0   ! Geometry's origin

    real(fp), parameter         :: y01                 = ly/2.d0   ! Geometry's origin

    real(fp), parameter         :: z01                 = 15.d0	    ! Geometry's origin

	!-----------Tandem Cyl 2-Solid reference position---------------!
	
	
	real(fp), parameter         :: x02                 = lx/2.d0   ! Geometry's origin

    real(fp), parameter         :: y02                 = ly/2.d0   ! Geometry's origin

    real(fp), parameter         :: z02                 = 17.d0	    ! Geometry's origin

	real(fp)					:: Zsplit_pos		   = 0.5d0*(z01+z02) ! Zs(k) position to split calculation between cylinder 1 and 2


    !--------------- Blade dynamic model function ------------------!

    real(fp), parameter         :: blade_alpha		   = 0.d0		! Cylinder spin ratio, + = CCW
	
    real(fp), parameter         :: blade_r             = 0.d0		! blade radius

	real(fp)					:: blade_omega


    !---------------- Rotor dynamic model function -----------------!

	real(fp), parameter			:: rotor_tsr		   = 0.d0		! + = CCW
	
    real(fp), parameter         :: rotor_r             = 0.d0		! rotor radius

    real(fp)					:: AOA1                = 0.d0       ! initial AOA (0 = z+, + = CCW)

    real(fp)					:: AOA_amp             = 0.d0       ! AOA amplitude

	real(fp)					:: rotor_omega

    real(fp), parameter         :: reduce_frequency_k  = 0.d0

    real(fp)                    :: AOA, dis_Y=0.d0, ratio, angular_vel=0.d0

	real(fp)            		:: T_gen	= 0.54d0*(0.5d0*den_flu*2.d0*(rotor_r+blade_r)*lx*U_inf*U_inf*(rotor_r+blade_r)) ! Generator torque (set constant for self start analysis)
	
	real(fp)					:: P_gen	= 0.4d0 *(0.5d0*den_flu*2.d0*(rotor_r+blade_r)*lx*U_inf**3)	! Generator power (set constant for steady analysis)



    !--------------- VIV of a cylinder ------------------!

    ! real(fp), parameter 	:: Ur_star 			= 12.d0
	
	! real(fp) 				:: k_spring 		= (2.d0 * PI / Ur_star) * (2.d0 * PI / Ur_star)
	
	! real(fp) 				:: c_damper 		= 4.d0 * PI * 0.01d0 / Ur_star



    !---------------------Solid motion------------------!

	real(fp)					:: x0_t, y0_t, z0_t !transformation of geometry's center due to 2way

	real(fp)					:: x0_t1, y0_t1, z0_t1 !transformation of geometry's center
	
	real(fp)					:: x0_t2, y0_t2, z0_t2 !transformation of geometry's center

	real(fp)					:: x0_t3, y0_t3, z0_t3 !transformation of geometry's center
	
    real(fp)                    :: u_solid, u_solid1, du_solid
    
    real(fp)                    :: v_solid, v_solid1, dv_solid
    
    real(fp)                    :: w_solid, w_solid1, dw_solid

    real(fp)                    :: u_solid_1, v_solid_1, w_solid_1
    
    real(fp)                    :: u_solid_2, v_solid_2, w_solid_2
	
	real(fp)					:: sol_speed


    !----------------------- heat transfer -------------------------!
	!!! Set thermal driven buoyancy term in QUICK.f90 !!!

    real(fp), parameter			:: Tsolid 		= 1.d0			! Isothermal solid temperature. (=0.d0 for insulation case)
	
    real(fp), parameter  		:: deltaT_max 	= 1.d0			! |T_hot - T_cold|
	
    real(fp), parameter  		:: cp_f 		= 1.21d-3		! Specific heat capacity of fluid

    real(fp), parameter         :: Pr 			= 0.72d0		! Fluid Prandtl number (for NON-dimensional simulation)
	
    real(fp)				    :: Gr 			= 1.d0*fixed_Re*fixed_Re	! Grashof number (for NON-dimensional simulation) Ri = Gr/Re/Re
	
    real(fp), parameter         :: Prt 			= 0.85d0		! Fluid sub-grid scale Prandtl number (same for most gas & liquids)

    real(fp)					:: alpha_s 		= 10.d0/fixed_Re/Pr	! Solid thermal diffusivity (note: alpha_f = 1/fixed_Re/Pr for NON-dimensional)
 
	real(fp), parameter         :: alpha_f 		= 1.8d-1		! fluid thermal diffusivity (for dimensional simulation)

    real(fp), parameter         :: beta_f 		= 3.3d-3		! Fluid volumetric expansion coefficient (for dimensional simulation)

	real(fp), parameter         :: heat_src		= 1.d0			! Heat source (in dimensional form: (watt/m^3)/(rho*Cp))

    real(fp)                    :: alpha_f_,buoy_accel

    real(fp)                    :: alpha,Tsolid1
	
    real(fp), dimension(:,:,:), allocatable	:: theta

    real(fp), dimension(:,:,:), allocatable	:: dtheta_dt

    real(fp), dimension(:,:,:), allocatable :: theta0,theta1
	
    real(fp), dimension(:,:,:), allocatable :: thetastar,thetastar1
	
    real(fp), dimension(:,:,:), allocatable :: Ftheta

    real(fp)                                :: totalFtheta,totalFtheta_,Qsolid,Nu_global

	real(fp)                                :: theta_spansum,dtheta_dt_spansum

    real(fp), dimension(1,1:ny,1:nz)        :: theta_spanavg,dtheta_dt_spanavg


	!-------------------- domain clipping for filer3d --------------!
	
	real(fp), parameter          :: x_start          = 0.d0		! Customize the filer output range
	real(fp), parameter          :: x_end            = lx
	
	real(fp), parameter          :: y_start          = 0.d0		!y0-6.d0
	real(fp), parameter          :: y_end            = ly		!y0+6.d0
	
	real(fp), parameter          :: z_start          = 0.d0		!z0-5.d0		
	real(fp), parameter          :: z_end            = lz		!z0+15.d0

	integer                      :: k_start,k_end,j_start,j_end,i_start,i_end


    !-------------------- Common VOS parameters -----------------------!

    real(fp), dimension(:,:,:), allocatable   :: ETA
	
	integer          			 :: iBgnVOS, iEndVOS , jBgnVOS, jEndVOS , kBgnVOS, kEndVOS	
	
    real(fp)                     :: Y_castingarea, Z_castingarea, X_castingarea, solid_volume, solid_volume_1, solid_volume_2, I_moment
	

    !------------------ VOS by Geometry function ----------------------!

    real(fp), parameter          :: r                   = 0.5d0	

    integer, parameter           :: nSubGrids_f 		= 100 !   --> for function

	integer, dimension(1:nz,1:ny)      	:: ETA_2D
	
	integer, dimension(1:nz,1:ny,1:nx)  :: ETA_3D
	

    !--------------------- VOS by RayCasting 2D -----------------------!

    integer, parameter            :: nSubGrids_2d = 100 !  --> for raycasting2d

    real(fp)                      :: min_dist = 2.d0*lySml/nySml ! minimum distance between parts --> for raycasting2d
	
    real(fp)                      :: z_length2D
	
	real(fp), dimension(:), allocatable :: iaz, iay
	
	integer						  :: poly

    character(len=50)             :: dat_file						 

    integer                       :: A, B, C, E

    integer, dimension(1:nz,1:ny) :: points

    integer, dimension(1:nz,1:ny) :: intersection

    real(fp), dimension(1:nz,1:ny):: ETA_1

    integer, dimension(1:nSubGrids_2d,1:nSubGrids_2d)     :: sub_intersection


    !--------------------- VOS by RayCasting 3D -----------------------!

    integer, parameter            :: nSubGrids_3d = 10 !   --> for raycasting3d

	integer*4                     :: nf=99999999		! max limit number of facets

	real(fp)                      :: z_length3D
	
	real(fp)                      :: ETAs
	
    character(len=50)             :: stl_file
	
	real*4  ,allocatable          :: iFN(:,:)
	
	real*4  ,allocatable          :: iPx(:), iPy(:), iPz(:)


    !--------------------------- Wall function ---------------------!
	
	real(fp), parameter	:: Kappa 		= 0.41d0 			! Von karman's constant

	real(fp), parameter	:: E_wm 		= 9.8d0				! An empirical wall coefficient (for smooth walls)
	
	real(fp), parameter	:: invE 		= 1.d0/9.8d0		! An empirical wall coefficient (for smooth walls)
	
	real(fp), parameter	:: ROOTVSMALL 	= 1.d-20 			! to avoid a division by zero
	
	integer, parameter	:: NRmaxIter 	= 20 				! Max number of Newton-Raphson interation
	
	real(fp), parameter	:: NRtolerance 	= 0.01d0 			! tolerance for Newton-Raphson interation

	integer 			:: wp_k, void, wp_j_up, wp_j_low, k_wp, j_wp, j_wpp
	
	real(fp)			:: wdistance,wdistance_,max_dist,wsin_,wcos_,hyp
	
	!real(fp), dimension(:), allocatable   			 :: wp_up,wp_low,z_wp

	!real(fp), dimension(:,:), allocatable 			 :: y_wp_up, y_wp_low

    real(fp), parameter   :: c_ref 		= 3.d0
	
    real(fp), parameter   :: yplusLam 	= 5.d0

    real(fp), dimension(1:ny,1:nz)  :: wdist,wsin,wcos,ypluss,upluss,fdamp
	
	integer 						:: NRit,countYplus,countYplus_
	
	real(fp)						:: NRerr,Ucp,Uwp,Urel,uTau,uTau_	! Urel is the relative velocity wrt wall
	
	real(fp)						:: kUu,fkUu,NR_f,NR_df
	
	real(fp)						:: yplusss,yplusMAX,yplusMIN
	
	real(fp)						:: yplusss_,yplusMAX_,yplusMIN_
	
	real(fp)						:: yplusSUM,yplusSUM_

	integer							:: ypluspts,ypluspts_

    real(fp), dimension(:,:,:), allocatable :: yplus_print,uplus_print,dist_print
	

    ! !--------------------------- Plasma ----------------------------!

    ! real(fp) ,dimension(1:nx,1:ny,1:nz)                :: F_tavex, F_tavey

    ! real(fp) ,dimension(1:nx,1:ny,1:nz)                :: edelta, EE

    ! real(fp)                                           :: PlasmaZc, PlasmaYc

    ! real(fp)                                           :: unDBD_cycle



    !-------------- Dimensional Plasma Parameter (SI) --------------!
    !real(fp), parameter :: theta                          = 3000.d0          
    !real(fp), parameter :: roc                            = 1.0e17
    !real(fp), parameter :: poto                           = 5656.85d0          
    !real(fp), parameter :: Eb                             = 3.0E6
    !real(fp), parameter :: delta_t                        = 6.7E-5  
    !real(fp), parameter :: alfa                           = 1.0
    !real(fp), parameter :: ec                             = 1.6e-19
    
    !real(fp), parameter :: reference_L                    = 0.127d0                                           !!! Chord length 127mm
    !real(fp), parameter :: Freestream                     = fixed_Re / reference_L * 1.47d0 * 1.0E-5               !!! Chord length 127mm


    !------------------ Dimensionaless Parameter -------------------!
    !real(fp), parameter :: len_d                          = 0.0075                                            ! Dimensionless Plasma parameter
    !real(fp), parameter :: len_a                          = 0.02
    !real(fp), parameter :: len_b                          = 0.0118  


    !real(fp) :: PlasmaVy1, PlasmaVy2, PlasmaVy3, PlasmaVz1, PlasmaVz2, PlasmaVz3
    !real(fp) :: PlasmaZr, PlasmaYr, PlasmaZu, PlasmaYu
    !real(fp) :: c1, c2, c3, E0, k1, k2
	

    !-------------------- iteration variable -----------------------!

    integer											:: ik, k, i, j, rb, istep, progress, ccc, ibackup
	
    real(fp)										:: time, initial_time, total_time, StartDynamic_time
	
    real(fp)										:: dt, dt_1, dt_2, dt_raw, constant_dt, constant_cfl
	
    real(fp)										:: prog_int, next_progress

    real(fp)										:: Re, nu, Re_t, inv_dt

    real(fp)										:: maxvel, maxvel_, u_x, v_y, w_z

    real(fp)										:: Um_sum_w,Um_sum_w_,Um_avg_w = U_inf

    real(fp)										:: Um_sum_e,Um_sum_e_,Um_avg_e = U_inf

    real(fp)										:: Um_sum_s,Um_sum_s_,Um_avg_s = U_inf

    real(fp)										:: Um_sum_n,Um_sum_n_,Um_avg_n = U_inf

    real(fp)										:: Um_sum_b,Um_avg_b = U_inf

    real(fp)										:: Um_sum_f,Um_avg_f = U_inf

	real(fp)										:: p_spansum, uc_spansum, vc_spansum, wc_spansum
   
    real(fp), dimension(:,:,:), allocatable			:: p, p_no
	
	! real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: p_old, p_new

    real(fp), dimension(:,:,:,:), allocatable		:: p_pre

    real(fp), dimension(:,:,:), allocatable			:: u, v, w
    
    real(fp), dimension(:,:,:), allocatable			:: u0, v0, w0
	
    real(fp), dimension(:,:,:), allocatable			:: u_TimeAvg, v_TimeAvg, w_TimeAvg, TKE, p_TimeAvg

    real(fp), dimension(:,:,:), allocatable			:: RS_uu, RS_uv, RS_uw, RS_vv, RS_vw, RS_ww

    real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u1, v1, w1
    
    real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u2, v2, w2 

    real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_star, v_star, w_star

    real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_star1, v_star1, w_star1

    real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_star2, v_star2, w_star2

    ! real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_star3, v_star3, w_star3

    ! real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_star4, v_star4, w_star4

    ! real(fp), dimension(-1:nx+2,-1:ny+2,-1:nz+2)	:: u_starm, v_starm, w_starm
	
    real(fp), dimension(1,1:ny,1:nz)				:: p_spanavg, uc_spanavg, vc_spanavg, wc_spanavg
	
    !------------------------ SOR -------------------------!

    integer                                 :: itmax

    real(fp)                                :: pNew, pChange, omega, pChangeMax, pChangeMax_, pSum, pSum_, pAvg

    real(fp), parameter                   	:: inv_nxyz=1.d0/(nx*ny*nz*1.d0)

    real(fp), dimension(1:nx,1:ny,1:nz)     :: mChange, Den, Den_inv

    real(fp), dimension(1:nx,1:ny,1:nz,1:6) :: P_Den

	real(fp) 								:: omega_max, omega_min, d_omega, log_zeta, k_zeta_zeta, x0_sigmoid
	
	real(fp), parameter 					:: k_zeta = 5.d0		! zeta multiplier to determine the zeta upper bound in dynamic omega
! 																	  set k_zeta to 0.5 for static omega = omega_max

	real(fp) 								:: log_k_zeta = LOG(k_zeta)

	real(fp) 								:: k_sigmoid = 5.d0		! Sigmoid steepness parameter

 
    !-------------------------- QUICK ------------------------------!

    real(fp), dimension(1:nx)   		  :: lw_u_tilde_1_p, lw_u_tilde_1_n, lw_u_tilde_2_p, lw_u_tilde_2_n

    real(fp), dimension(1:nx)   		  :: qw_u_tilde_1_p, qw_u_tilde_1_n, qw_u_tilde_2_p, qw_u_tilde_2_n

    real(fp), dimension(1:ny)   		  :: lw_v_tilde_1_p, lw_v_tilde_1_n, lw_v_tilde_2_p, lw_v_tilde_2_n

    real(fp), dimension(1:ny)   		  :: qw_v_tilde_1_p, qw_v_tilde_1_n, qw_v_tilde_2_p, qw_v_tilde_2_n
	
	real(fp), dimension(1:nz)   		  :: lw_w_tilde_1_p, lw_w_tilde_1_n, lw_w_tilde_2_p, lw_w_tilde_2_n

	real(fp), dimension(1:nz)   		  :: qw_w_tilde_1_p, qw_w_tilde_1_n, qw_w_tilde_2_p, qw_w_tilde_2_n

	real(fp) 							  :: ucc, ue1, uw1, ue2, uw2, un1, us1, un2, us2, uf1, ub1, uf2, ub2

	real(fp) 							  :: vcc, ve1, vw1, ve2, vw2, vn1, vs1, vn2, vs2, vf1, vb1, vf2, vb2

	real(fp) 							  :: wcc, we1, ww1, we2, ww2, wn1, ws1, wn2, ws2, wf1, wb1, wf2, wb2

	real(fp) 							  :: tcc, te1, tw1, te2, tw2, tn1, ts1, tn2, ts2, tf1, tb1, tf2, tb2

    real(fp) 							  :: ETA_face

    real(fp)                              :: u_tilde_x1, u_tilde_x2, u_tilde_y1, u_tilde_y2, u_tilde_z1, u_tilde_z2 
    
    real(fp)                              :: v_tilde_x1, v_tilde_x2, v_tilde_y1, v_tilde_y2, v_tilde_z1, v_tilde_z2
    
    real(fp)                              :: w_tilde_x1, w_tilde_x2, w_tilde_y1, w_tilde_y2, w_tilde_z1, w_tilde_z2
    
    real(fp)                              :: ue, uw, un, us, uf, ub, vnu, vsu, wfu, wbu
    
    real(fp)                              :: ve, vw, vn, vs, vf, vb, uev, uwv, wfv, wbv
    
    real(fp)                              :: we, ww, wn, ws, wf, wb, uew, uww, vnw, vsw


    !---------------------------- BICG -----------------------------!

    !integer, parameter                   :: s=nx*ny*nz, nxy=nx*ny
!
    !real(fp), dimension(1:3,1:7*s)         :: aa
!
    !real(fp), dimension(1:s)               :: r0, bm, rm, p0, uu, xm, xmp, ap, ss, as
!
    !real(fp)                               :: alpha, om, beta, gamap, sub, gama, apr, asas, ass



    !---------------------------- LES ------------------------------!

    real(fp), parameter                   :: Cs = 0.1d0		! Smagorinsky constant
	
    real(fp), parameter                   :: Cw = 0.5d0		! WALE constant

    real(fp)                              :: strainRateTensor,delta
	
	real(fp)                              :: Viseff_e,Viseff_w,Viseff_n,Viseff_s,Viseff_f,Viseff_b

    real(fp), dimension(:,:,:), allocatable :: nut

       !-------------Wall Damping Function-------------------------------!
                               
		real(fp)                            ::    Cf, cf_d
  
		real(fp)                            ::    tau, tau_d
 
		real(fp)                            ::    ufric, ufric_d
 
		real(fp)                            ::    Yplus, yplus_d
 
		real(fp)                            ::    fwall, fwall_d 



    !------------------- virtualForceIntegrator --------------------!
	
	real(fp)                              	:: ref_area, area_ref
    
    real(fp), dimension(:,:,:), allocatable :: FX, FY, FZ

    real(fp), dimension(:,:,:), allocatable :: FX1, FY1, FZ1
    
    real(fp)                                :: totalFX, totalFY, totalFZ

    real(fp)                                :: totalFZ1, totalFY1, totalFX1
	
    real(fp)                                :: totalFZ2, totalFY2, totalFX2
	
    real(fp)                                :: totalFZ3, totalFY3, totalFX3

    real(fp)                                :: totalFX_, totalFY_, totalFZ_

    real(fp)                                :: totalFZ1_, totalFY1_, totalFX1_
	
    real(fp)                                :: totalFZ2_, totalFY2_, totalFX2_
	
    real(fp)                                :: totalFZ3_, totalFY3_, totalFX3_
	
    real(fp)                                :: totalTX, totalTY, totalTZ, totalTorq, totalTorq1_in, totalTorq2_in, totalTorq3_in
	
    real(fp)                                :: totalTY1, totalTZ1, totalTY2, totalTZ2, totalTY3, totalTZ3

    real(fp)                                :: totalTY1_in, totalTZ1_in, totalTY2_in, totalTZ2_in, totalTY3_in, totalTZ3_in

    real(fp)                                :: totalTorq1, totalTorq2, totalTorq3

    real(fp)                                :: totalTX_, totalTY_, totalTZ_, totalTorq_

    real(fp)                                :: totalTY1_, totalTZ1_, totalTY2_, totalTZ2_, totalTY3_, totalTZ3_

    real(fp)                                :: totalTY1_in_, totalTZ1_in_, totalTY2_in_, totalTZ2_in_, totalTY3_in_, totalTZ3_in_
    
	real(fp)                                :: totalTorqx, totalTorqy, totalTorqz
	
	real(fp)                                :: totalT_XZ, totalT_XY
	
	real(fp)                                :: totalT_YZ, totalT_YX
	
	real(fp)                                :: totalT_ZY, totalT_ZX
	
	real(fp)                                :: totalT_XZ_, totalT_XY_
	
	real(fp)                                :: totalT_YZ_, totalT_YX_
	
	real(fp)                                :: totalT_ZY_, totalT_ZX_


    real(fp)                                :: cDrag ,cLift, cTorq, cPower, cPower_in, cPower_nett
	
    real(fp)                                :: cDrag1 ,cLift1, cTorq1, cPower1, cPower1_in
	
    real(fp)                                :: cDrag2 ,cLift2, cTorq2, cPower2, cPower2_in

    real(fp)                                :: cDrag3 ,cLift3, cTorq3, cPower3, cPower3_in

    real(fp), dimension(1:nx,1:ny)          :: FXz, FYz, FZz
    
    real(fp), dimension(1:nx)               :: FXy, FYy, FZy

	real(fp)                                :: rotate_sx, rotate_sy, rotate_sz

	! real(fp), dimension(1:nx,1:ny,1:nz)	:: fric_coeff, moment_dist, CF_TimeAvg
	real(fp), dimension(0:360,1:nx)			:: fric_coeff, moment_dist, CF_TimeAvg
	
	real(fp)                                :: tau_moment, tau_moment_

	integer									:: stepavg

	real(fp)                                :: tau_moment1, tau_moment1_

	real(fp)                                :: tau_moment2, tau_moment2_

	real(fp)                                :: tau_moment3, tau_moment3_


    !--------------------------- output ----------------------------!
    
    character(len=20)                     	:: filename, fileformat

    integer, parameter                    	:: nblocks = 1
    
    real, dimension(1:nx,1:ny,1:nz)       	:: Xout, Yout, Zout
    
    real, dimension(1:nx,1:ny,1:nz,5)     	:: Qout
    
    real                                  	:: temp = 1.0    ! mach, alpha, reyn, time 
    
    integer                               	:: h,num
	
    real(fp), dimension(1:nx,1:ny,1:nz)   	:: uc,vc,wc

    real(fp), dimension(1:nx,1:ny,1:nz)   	:: FXc,FYc,FZc
	

		!-------------------------Points Prober---------------------!
	
		! integer, parameter					  :: n_points = 3 ! Insert number of probes

		! real(fp), dimension (n_points)		  :: probe_u,probe_v,probe_w,probe_p

		! integer, dimension (3*n_points) 	  :: near_pt
	
		! real(fp), dimension (3*n_points)		  :: probe =[ &


			! !Insert probe coordinates (x,y,z)		
				! 1.d0, 12.d0, 12.d0				,&  !point 1 (x1,y1,z1)
				! 1.d0, 12.d0, 14.d0				,&	!point 2 (x2,y2,z2)
				! 1.d0, 12.d0, 16.d0				]	!point 3 (x3,y3,z3)
  

    !--------------------------- input -----------------------------!
    
    integer					:: inblocks
    
    integer					:: inx
    
    integer					:: iny
    
    integer					:: inz 
	
	real(fp)				:: lastsaved_time
    
    character(len=20)		:: inputfile
    


    !---------------------------- Grid -----------------------------!

    !Initial grid coordinates for evaluating grid lengths
    real(fp), dimension (-1:nx+3)		:: X

    real(fp), dimension (-1:ny+3)		:: Y

    real(fp), dimension (-1:nz+3)		:: Z 

    !Grid lengths
    real(fp), dimension (-1:nx+2)		:: iDx

    real(fp), dimension (-1:nx+2)		:: Dxs

    real(fp), dimension (-1:ny+2)		:: iDy

    real(fp), dimension (-1:ny+2)		:: Dys

    real(fp), dimension (-1:nz+2)		:: iDz

    real(fp), dimension (-1:nz+2)		:: Dzs

    !Midpoints of grid coordinates
    real(fp), dimension (1:nx)			:: Xs

    real(fp), dimension (1:ny)			:: Ys

    real(fp), dimension (1:nz)			:: Zs

  
    !--------------------------- OPENMP ----------------------------!

    integer                      :: nthreads


    !-------------------------- MPI (MAIN) -------------------------!

    integer                      :: nproc, myid, ierr, local_rank

	character(len=8) 			 :: rank_str

    integer                      :: status(MPI_STATUS_SIZE)

    integer, parameter           :: master=0

    integer, dimension(:), allocatable :: gstart ,gend, gcount

    integer                      :: Zdv, Zr

    integer                      :: l_nbr, r_nbr, icount, iend, istart, itag, igcount
	
	real						 :: igcount_min


    !-------------------------- MPI (VoS) -------------------------!
	
    integer, dimension(:), allocatable :: gstart_vos ,gend_vos, gcount_vos

    integer                      :: Zdv_vos, Zr_vos

    integer                      :: iend_vos, istart_vos, igcount_vos	




    !--------------------- calculate wall time ---------------------!
    
    character(len=8)  		 :: date_str

	character(len=10)  		 :: time_str
	
	real(fp)                 :: totalstarttime, vosstarttime

    real(fp)                 :: totalfinaltime, vosfinaltime

    real(fp)                 :: totalcosttime

    real(fp)                 :: totallasttime, lastprogresstime, lastbackuptime
	
    real(fp)                 :: timeapproxstart, timeapproxend
	
	real(fp)				 :: time1start, time2start, time3start, time4start, time5start, time6start

	real(fp)				 :: time1end, time2end, time3end, time4end, time5end, time6end



    !--------------------------- toggle ----------------------------!


	character(len=5)		 :: time_stepping_by

	character(len=5)		 :: LES_mode

	character(len=5)		 :: wall_model

	character(len=5)		 :: heat_transfer, heat_source, natural_conv

    integer                  :: LES
	
    integer                  :: Damping_F

    character(len=5)         :: resume

    real(fp)                 :: zeta_vel

    real(fp)                 :: zeta

    integer                  :: VOS_by
	
    integer                  :: select_ref_area

    real(fp)                 :: user_defined

    integer                  :: solid_motion

    integer                  :: DBD

    real(fp)                 :: unDBD

    integer                  :: unDBD_onoff
	
    integer                  :: pressure_solver	

    integer                  :: correction_stage
	
    real(fp)                 ::	startHeatTransfer_time, StartCorrection_time
	
	integer					 :: dimensionality

    character(len=8)         :: filer3d, filer2d, filer_cp

    character(len=8)         :: filer_virtual_force,filer_running_avg,filer_near_wall
	
    real(fp)				 :: backup_int, coeff_start, start_running_avg_time
	
	real(fp)                 :: startfiler3d_time, startfiler2d_time, startfilerVF_time, startfilerAvg_time, startfilerNW_time

	real(fp)                 :: filer3d_int, filer2d_int, istocp_int, filerVF_int, filerAvg_int, filerCp_int, filerNW_int

	real(fp)                 :: next_filer3d, next_filer2d, next_filerVF, next_filerAvg, next_filerNW

	real(fp)                 :: next_backup, next_backupAvg, next_filerCp



CONTAINS

!-------------------- Common functions -------------------------
function bilinear_interp(y, z, y0, y1, z0, z1, f) result(val)
    implicit none
!$acc routine

    real(fp), intent(in) :: y, z
    real(fp), intent(in) :: y0, y1, z0, z1
    real(fp), intent(in) :: f(2,2)
    real(fp) :: val
    real(fp) :: ty, tz

	ty = (y - y0) / (y1 - y0)
	tz = (z - z0) / (z1 - z0)

    val = f(1,1)*(1.d0-ty)*(1.d0-tz) + &
          f(2,1)*ty       *(1.d0-tz) + &
          f(1,2)*(1.d0-ty)*tz        + &
          f(2,2)*ty       *tz
end function bilinear_interp


function trilinear_interp(x, y, z, x0, x1, y0, y1, z0, z1, f) result(val)
	implicit none
!$acc routine

  real(fp), intent(in) :: x, y, z
  real(fp), intent(in) :: x0, x1, y0, y1, z0, z1
  real(fp), intent(in) :: f(2,2,2)
  real(fp) :: val
  real(fp) :: tx, ty, tz

  tx = (x - x0) / (x1 - x0)
  ty = (y - y0) / (y1 - y0)
  tz = (z - z0) / (z1 - z0)

  val = f(1,1,1)*(1.d0-tx)*(1.d0-ty)*(1.d0-tz) + &
        f(2,1,1)*tx       *(1.d0-ty)*(1.d0-tz) + &
        f(1,2,1)*(1.d0-tx)*ty       *(1.d0-tz) + &
        f(2,2,1)*tx       *ty       *(1.d0-tz) + &
        f(1,1,2)*(1.d0-tx)*(1.d0-ty)*tz        + &
        f(2,1,2)*tx       *(1.d0-ty)*tz        + &
        f(1,2,2)*(1.d0-tx)*ty       *tz        + &
        f(2,2,2)*tx       *ty       *tz
end function trilinear_interp


end module
