! 05 May 2026 - FDS


subroutine discretisation_QUICK_HT()			! theta at cell center, non-uniform grid
  use variables
  implicit none
  real(fp)	:: a1,a2,a3	
  real(fp)	:: tte,ttw,ttn,tts,ttf,ttb

!$acc data present(iDx,iDy,iDz,Dxs,Dys,Dzs,nut(:,:,istart:iend+1), &
!$acc	     u(:,:,istart-2:iend+2), v(:,:,istart-2:iend+2), w(:,:,istart-2:iend+2), &
!$acc	theta(:,:,istart-2:iend+2),thetastar(:,:,istart-2:iend+2))

   !$OMP PARALLEL DO      PRIVATE(a1,a2,a3,tte,ttw,ttn,tts,ttf,ttb,alpha) COLLAPSE(3)
   !$acc parallel
   !$acc loop independent private(a1,a2,a3,tte,ttw,ttn,tts,ttf,ttb,alpha) collapse(3) gang vector
   do k=istart,iend
   do j=1,ny; do i=1,nx

		if (u(i,j,k) > 0.d0) then
			a1=  (0.5d0*iDx(i)*(Dxs(i-1) + 0.5d0*iDx(i)))/(Dxs(i)*Dxs(i-1))
            a2=(0.5d0*iDx(i+1)*(Dxs(i-1) + 0.5d0*iDx(i)))/(Dxs(i)*(Dxs(i-1) + Dxs(i)))
            a3=              -0.5d0*iDx(i)*0.5d0*iDx(i+1)/(Dxs(i-1)*(Dxs(i-1) + Dxs(i)))
            tte=a1*theta(i,j,k)+a2*theta(i+1,j,k)+a3*theta(i-1,j,k)
        else
			a1=(0.5d0*iDx(i+1)*(Dxs(i+1) + 0.5d0*iDx(i+1)))/(Dxs(i)*Dxs(i+1))
            a2=  (0.5d0*iDx(i)*(Dxs(i+1) + 0.5d0*iDx(i+1)))/(Dxs(i)*(Dxs(i+1) + Dxs(i)))
            a3=              -(0.5d0*iDx(i)*0.5d0*iDx(i+1))/(Dxs(i+1)*(Dxs(i+1) + Dxs(i)))
            tte=a1*theta(i+1,j,k)+a2*theta(i,j,k)+a3*theta(i+2,j,k)
        endif

        if (u(i-1,j,k) > 0.d0) then
			a1=(0.5d0*iDx(i-1)*(Dxs(i-2) + 0.5d0*iDx(i-1)))/(Dxs(i-1)*Dxs(i-2))
            a2=  (0.5d0*iDx(i)*(Dxs(i-2) + 0.5d0*iDx(i-1)))/(Dxs(i-1)*(Dxs(i-2) + Dxs(i-1)))
            a3=              -(0.5d0*iDx(i-1)*0.5d0*iDx(i))/(Dxs(i-2)*(Dxs(i-2) + Dxs(i-1)))
            ttw=a1*theta(i-1,j,k)+a2*theta(i,j,k)+a3*theta(i-2,j,k)
        else
			a1=  (0.5d0*iDx(i)*(Dxs(i) + 0.5d0*iDx(i)))/(Dxs(i-1)*Dxs(i))
            a2=(0.5d0*iDx(i-1)*(Dxs(i) + 0.5d0*iDx(i)))/(Dxs(i-1)*(Dxs(i) + Dxs(i-1)))
            a3=          -(0.5d0*iDx(i-1)*0.5d0*iDx(i))/(Dxs(i)*(Dxs(i) + Dxs(i-1)))
            ttw=a1*theta(i,j,k)+a2*theta(i-1,j,k)+a3*theta(i+1,j,k)
		endif


        if (v(i,j,k) > 0.d0) then
			a1=	 (0.5d0*iDy(j)*(Dys(j-1) + 0.5d0*iDy(j)))/(Dys(j)*Dys(j-1))
            a2=(0.5d0*iDy(j+1)*(Dys(j-1) + 0.5d0*iDy(j)))/(Dys(j)*(Dys(j-1) + Dys(j)))
            a3=              -0.5d0*iDy(j)*0.5d0*iDy(j+1)/(Dys(j-1)*(Dys(j-1) + Dys(j)))
            ttn=a1*theta(i,j,k)+a2*theta(i,j+1,k)+a3*theta(i,j-1,k)
        else
			a1=(0.5d0*iDy(j+1)*(Dys(j+1) + 0.5d0*iDy(j+1)))/(Dys(j)*Dys(j+1))
            a2=  (0.5d0*iDy(j)*(Dys(j+1) + 0.5d0*iDy(j+1)))/(Dys(j)*(Dys(j+1) + Dys(j)))
            a3=              -(0.5d0*iDy(j)*0.5d0*iDy(j+1))/(Dys(j+1)*(Dys(j+1) + Dys(j)))
            ttn=a1*theta(i,j+1,k)+a2*theta(i,j,k)+a3*theta(i,j+2,k)
        endif

        if (v(i,j-1,k) > 0.d0) then
			a1=(0.5d0*iDy(j-1)*(Dys(j-2) + 0.5d0*iDy(j-1)))/(Dys(j-1)*Dys(j-2))
            a2=  (0.5d0*iDy(j)*(Dys(j-2) + 0.5d0*iDy(j-1)))/(Dys(j-1)*(Dys(j-2) + Dys(j-1)))
            a3=                -0.5d0*iDy(j-1)*0.5d0*iDy(j)/(Dys(j-2)*(Dys(j-2) + Dys(j-1)))
            tts=a1*theta(i,j-1,k)+a2*theta(i,j,k)+a3*theta(i,j-2,k)
        else
			a1=  (0.5d0*iDy(j)*(Dys(j) + 0.5d0*iDy(j)))/(Dys(j-1)*Dys(j))
            a2=(0.5d0*iDy(j-1)*(Dys(j) + 0.5d0*iDy(j)))/(Dys(j-1)*(Dys(j) + Dys(j-1)))
            a3=          -(0.5d0*iDy(j-1)*0.5d0*iDy(j))/(Dys(j)*(Dys(j) + Dys(j-1)))
            tts=a1*theta(i,j,k)+a2*theta(i,j-1,k)+a3*theta(i,j+1,k)
		endif


        if (w(i,j,k) > 0.d0) then
			a1=	 (0.5d0*iDz(k)*(Dzs(k-1) + 0.5d0*iDz(k)))/(Dzs(k)*Dzs(k-1))
            a2=(0.5d0*iDz(k+1)*(Dzs(k-1) + 0.5d0*iDz(k)))/(Dzs(k)*(Dzs(k-1) + Dzs(k)))
            a3=              -0.5d0*iDz(k)*0.5d0*iDz(k+1)/(Dzs(k-1)*(Dzs(k-1) + Dzs(k)))
            ttf=a1*theta(i,j,k)+a2*theta(i,j,k+1)+a3*theta(i,j,k-1)
        else
			a1=(0.5d0*iDz(k+1)*(Dzs(k+1) + 0.5d0*iDz(k+1)))/(Dzs(k)*Dzs(k+1))
            a2=  (0.5d0*iDz(k)*(Dzs(k+1) + 0.5d0*iDz(k+1)))/(Dzs(k)*(Dzs(k+1) + Dzs(k)))
            a3=              -(0.5d0*iDz(k)*0.5d0*iDz(k+1))/(Dzs(k+1)*(Dzs(k+1) + Dzs(k)))
            ttf=a1*theta(i,j,k+1)+a2*theta(i,j,k)+a3*theta(i,j,k+2)
        endif

        if (w(i,j,k-1) > 0.d0) then
			a1=(0.5d0*iDz(k-1)*(Dzs(k-2) + 0.5d0*iDz(k-1)))/(Dzs(k-1)*Dzs(k-2))
            a2=  (0.5d0*iDz(k)*(Dzs(k-2) + 0.5d0*iDz(k-1)))/(Dzs(k-1)*(Dzs(k-2) + Dzs(k-1)))
            a3=                -0.5d0*iDz(k-1)*0.5d0*iDz(k)/(Dzs(k-2)*(Dzs(k-2) + Dzs(k-1)))
            ttb=a1*theta(i,j,k-1)+a2*theta(i,j,k)+a3*theta(i,j,k-2)
        else
			a1=  (0.5d0*iDz(k)*(Dzs(k) + 0.5d0*iDz(k)))/(Dzs(k-1)*Dzs(k))
            a2=(0.5d0*iDz(k-1)*(Dzs(k) + 0.5d0*iDz(k)))/(Dzs(k-1)*(Dzs(k) + Dzs(k-1)))
            a3=          -(0.5d0*iDz(k-1)*0.5d0*iDz(k))/(Dzs(k)*(Dzs(k) + Dzs(k-1)))
            ttb=a1*theta(i,j,k)+a2*theta(i,j,k-1)+a3*theta(i,j,k+1)
		endif

		alpha = (1.d0-ETA(i,j,k)) * (alpha_f_ + nut(i,j,k)/Prt) + ETA(i,j,k)*alpha_s

        thetastar(i,j,k) = - (u(i,j,k)*tte-u(i-1,j,k)*ttw) / iDx(i) 	&
						   - (v(i,j,k)*ttn-v(i,j-1,k)*tts) / iDy(j) 	&
						   - (w(i,j,k)*ttf-w(i,j,k-1)*ttb) / iDz(k) 	&

                       + alpha*( (theta(i+1,j,k)-theta(i,j,k)) / Dxs(i) - (theta(i,j,k)-theta(i-1,j,k)) / Dxs(i-1) ) / iDx(i) &
                       + alpha*( (theta(i,j+1,k)-theta(i,j,k)) / Dys(j) - (theta(i,j,k)-theta(i,j-1,k)) / Dys(j-1) ) / iDy(j) &
                       + alpha*( (theta(i,j,k+1)-theta(i,j,k)) / Dzs(k) - (theta(i,j,k)-theta(i,j,k-1)) / Dzs(k-1) ) / iDz(k)
                        
  	end do;end do;end do
	!$acc end parallel   
    !$OMP END PARALLEL DO


!$acc end data

end subroutine discretisation_QUICK_HT


subroutine AdamsBashforth_HT()
    use variables
    implicit none
    real(fp)	:: r_dt1, r_dt2, c2_a, c2_b


!$acc data present(theta(:,:,istart-2:iend+2),theta0(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2), &
!$acc			   thetastar(:,:,istart-2:iend+2),thetastar1(:,:,istart-2:iend+2))

	r_dt1 = dt_1/dt			!2nd order

    if( istep >= 2) then

		c2_a  = 1.d0 + 0.5d0/r_dt1		!2nd order
		c2_b  = -0.5d0/r_dt1			!2nd order

		!$OMP PARALLEL DO COLLAPSE(3) 
		!$acc parallel loop independent collapse(3) gang vector 
		do k=istart,iend 
		do j=1,ny; do i=1,nx
		
            theta0(i,j,k) = theta(i,j,k) + ( c2_a * thetastar(i,j,k) + c2_b * thetastar1(i,j,k) ) * dt
			theta1(i,j,k) = theta0(i,j,k)

			thetastar1(i,j,k) = thetastar(i,j,k)		!2nd order

		enddo; enddo; enddo
		!$acc end parallel
		!$OMP END PARALLEL DO


    else if( istep == 1) then

		!$OMP PARALLEL DO COLLAPSE(3) 
		!$acc parallel loop independent collapse(3) gang vector 
		do k=istart,iend 
		do j=1,ny; do i=1,nx

            theta0(i,j,k) = theta(i,j,k) + thetastar(i,j,k) * dt
			theta1(i,j,k) = theta0(i,j,k)

			thetastar1(i,j,k) = thetastar(i,j,k)		!2nd order

		enddo; enddo; enddo
		!$acc end parallel
		!$OMP END PARALLEL DO

    end if


!$acc end data	

	dt_1  = dt			!2nd order
	
end subroutine AdamsBashforth_HT



subroutine calcul_new_theta()
   use variables
   implicit none
   
! Sending data to accelerator
!$acc data present(ETA,theta0(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2),Ftheta(:,:,istart-2:iend+2))

  !$OMP PARALLEL DO   PRIVATE(Tsolid1) COLLAPSE(3)
  !$acc parallel loop private(Tsolid1) collapse(3) gang vector
   do k=istart,iend 
   do j=1,ny;do i=1,nx
      
	  Tsolid1 = Tsolid

      theta1(i,j,k) = ETA(i,j,k) * Tsolid1 + (1.d0- ETA(i,j,k)) * theta0(i,j,k)
      
      Ftheta(i,j,k) = (theta1(i,j,k) - theta0(i,j,k)) * inv_dt
	  
   end do; end do; end do
   !$acc end parallel 
   !$OMP END PARALLEL DO

!$acc end data

end subroutine calcul_new_theta



subroutine Updating_theta()
   use variables
   implicit none

!$acc data present(theta(:,:,istart-2:iend+2),theta1(:,:,istart-2:iend+2),dtheta_dt(:,:,istart-2:iend+2))


   !$OMP PARALLEL DO COLLAPSE(3) 
   !$acc parallel loop collapse(3) gang vector
   do k=istart,iend  
   do j=1,ny;do i=1,nx

	  dtheta_dt(i,j,k) = (theta1(i,j,k) - theta(i,j,k))  * inv_dt

      theta(i,j,k) = theta1(i,j,k)    		

   end do; end do; end do
   !$acc end parallel
   !$OMP END PARALLEL DO


!$acc end data   
   
end subroutine Updating_theta



subroutine thermalForceIntegrator()
	use variables
	implicit none

	totalFtheta = 0.d0

!$acc data present(iDx,iDy,iDz,Ftheta(:,:,istart-2:iend+2))

   !$OMP PARALLEL DO 			   REDUCTION(+: totalFtheta) COLLAPSE(3)
   !$acc parallel loop independent reduction(+: totalFtheta) collapse(3) gang vector
	do k=istart,iend 
	do j=1,ny;do i=1,nx
	
	  if(ETA(i,j,k) .GT. 0.d0) then
		totalFtheta = totalFtheta + ( Ftheta(i,j,k) * iDx(i)*iDy(j)*iDz(k) )
	  endif
	end do;end do;end do
   !$acc end parallel 
   !$OMP END PARALLEL DO
!$acc end data 

    call MPI_ALLREDUCE( totalFtheta, totalFtheta_, 1, MPI_REAL8, MPI_SUM, MPI_COMM_WORLD, ierr )

	Qsolid = - den_flu*cp_f*totalFtheta_		! Solid Cooling/Heating rate
	
	Nu_global = - totalFtheta_/alpha_f_/deltaT_max	! Nusselt*A/L

end subroutine thermalForceIntegrator